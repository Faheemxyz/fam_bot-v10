const fs = require('fs')
const file = require.resolve(__filename)


global.ownerNumber = ["923350963366@s.whatsapp.net"]
global.nomerOwner = "923350963366"
global.nomorOwner = ['923350963366']
global.namaDeveloper = "千卂爪-ㄖ千匚" //jangn diubh bng
global.namaOwner = "千卂爪-ㄖ千匚"
global.namaBot = "Fam-bot"
global.versionBot = "ꪜ10"
global.packname = "𝐅𝐀𝐌 𝐎𝐅𝐂 ꪜ1"
global.author = "✨ FAM OFC MD ✨"
global.ThM = 'https://iili.io/2yFPx0F.png'
global.prefa = ['','!','.',',','🐤','🗿'] 
global.travaSend = "1" // total travas a ser enviado



fs.watchFile(file, () => {
fs.unwatchFile(file)
console.log(`Update ${__filename}`)
delete require.cache[file]
require(file)
})